//
//  Player.m
//  ReinforcementLearningGame
//
//  Created by Zois Avgerinos on 9/25/13.
//  Copyright (c) 2013 Zois Avgerinos. All rights reserved.
//

#import "Player.h"

@implementation Player
@synthesize position = _position;
@synthesize name = _name;
@synthesize peerID = _peerID;
@synthesize receivedResponse = _receivedResponse;

- (NSString *)description
{
	return [NSString stringWithFormat:@"%@ peerID = %@, name = %@, position = %d", [super description], self.peerID, self.name, self.position];
}
@end

//
//  JoinGame.h
//  RL_Game
//
//  Created by Zois Avgerinos on 9/17/13.
//  Copyright 2013 Zois Avgerinos. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "Client.h"

@class JoinGame;

@protocol JoinGameDelegate <NSObject>


- (void)joinViewController:(JoinGame *)controller didDisconnectWithReason:(QuitReason)reason;
- (void)joinViewController:(JoinGame *)controller startClientGameWithSession:(GKSession *)session playerName:(NSString *)name server:(NSString *)peerID;

@end


@interface JoinGame : CCLayer<ClientDelegate> {
    
}
@property (nonatomic, strong) IBOutlet CCLabelTTF *joinLabel;
@property (nonatomic, strong) IBOutlet CCLabelTTF *nameLabel;
@property (nonatomic, strong) IBOutlet CCLabelTTF *name_Label;
@property (nonatomic, strong) IBOutlet CCLabelTTF *connectingLabel;
@property (nonatomic, strong) IBOutlet CCLabelTTF *connectedLabel;
@property (nonatomic, strong) id <JoinGameDelegate> delegate;


+(CCScene *) scene;
@end

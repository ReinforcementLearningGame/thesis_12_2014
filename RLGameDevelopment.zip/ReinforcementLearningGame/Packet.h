//
//  Packet.h
//  ReinforcementLearningGame
//
//  Created by Zois Avgerinos on 9/25/13.
//  Copyright (c) 2013 Zois Avgerinos. All rights reserved.
//

#import <Foundation/Foundation.h>
const size_t PACKET_HEADER_SIZE;
typedef enum
{
	PacketTypeSignInRequest = 0x64,    // server to client
	PacketTypeSignInResponse,          // client to server
    
	PacketTypeServerReady,             // server to client
	PacketTypeClientReady,             // client to server
    
	PacketTypeMove,
    
    //PacketTypeServerMoveX,               // server to client
	//PacketTypeClientMoveO,              // client to server
    
	//PacketTypeOtherClientQuit,         // server to client
	PacketTypeServerQuit,              // server to client
	PacketTypeClientQuit,              // client to server
}
PacketType;

@interface Packet : NSObject

@property (nonatomic, assign) PacketType packetType;

+ (id)packetWithType:(PacketType)packetType;
- (id)initWithType:(PacketType)packetType;
- (NSData *)data;
+ (id)packetWithData:(NSData *)data;
@end
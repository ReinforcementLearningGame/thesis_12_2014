//
//  Player.h
//  ReinforcementLearningGame
//
//  Created by Zois Avgerinos on 9/25/13.
//  Copyright (c) 2013 Zois Avgerinos. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum
{
	PlayerPositionBottom,  // the user
	PlayerPositionLeft,
	PlayerPositionTop,
	PlayerPositionRight
}
PlayerPosition;

@interface Player : NSObject

@property (nonatomic, assign) PlayerPosition position;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *peerID;
@property (nonatomic, assign) BOOL receivedResponse;
@end
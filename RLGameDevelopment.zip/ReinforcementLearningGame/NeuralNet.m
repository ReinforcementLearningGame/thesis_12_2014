//
//  NeuralNet.m
//  ReinforcementLearningGame
//
//  Created by Zois Avgerinos on 11/13/13.
//  Copyright (c) 2013 Zois Avgerinos. All rights reserved.
//

#import "NeuralNet.h"
#import "Constants.h"
#import "Pawn.h"



@implementation NeuralNet

-(void)initWithParams:(int)which :(int)input :(int)hidden :(int)output :(double)gamma :(double)lambda{
    
        //the id of the player who owns the neural
        owner=which;
        //number of inputs=2*((BOARD*BOARD-2*BASE*BASE+5))=122
        inputNodes = input;
        //number of hidden
        hiddenNodes = hidden;
        //number of output=1
        outputNodes = output;
      
        GAMMA = gamma; //discount-rate parameter
        LAMBDA = lambda; //trace decay parameter
        ALPHA=1.0/inputNodes; //1-st layer learning rate
        BETA=1.0/hiddenNodes; //2-nd layer learning rate
        BIAS = 0.5;
        
        //if (![[NSUserDefaults standardUserDefaults]objectForKey:@"v_weights"]) {
            //NSLog(@"INIT");
        [self initNetwork]; //initializes the network data structures
        //}
}


/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
/* Initialize weights and biases */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
-(void)initNetwork{
    int j,k,i;
    @try
    {
		[self loadWeights:@"v_weights" ww:@"w_weights"]; // used for the next executions, loads the stored weights
        NSLog(@"LOAD WEIGHTS");
	}
    @catch(NSException *e)
    {
        NSLog(@"INIT WEIGHTS");
        [self initWeights];// used only for the first execution, just to randomize the weights
	}
    //[self initWeights];
    inputNode[inputNodes]=BIAS; // last input node is set to BIAS
    hiddenNode[hiddenNodes]=BIAS; // last hidden node is set to BIAS
    
    for(j=0;j<=hiddenNodes;j++)
    {
        for(k=0;k<outputNodes;k++)
        {
            ew[j][k]=0.0;
            oldOutputNode[k]=0.0;
        }
        for(i=0;i<=inputNodes;i++)
        {
            for(k=0;k<outputNodes;k++)
            {
                ev[i][j][k]=0.0;
            }
        }
    }
}
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
/* Initializes the weights v[][] and w[][] with a small random number */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
-(void) initWeights
{
    int j,k,i;
    
        for(j=0;j<=hiddenNodes;j++)
    {
        for (k=0;k<outputNodes;k++)
        {
            srand48(time(0));
            w[j][k]= drand48();
            //NSLog(@"w[%i][%i]=%f",j,k,w[j][k]);
        }
        for(i=0;i<=inputNodes;i++)
        {
            v[i][j]=drand48();
        }
    }
    [self storeWeights:@"v_weights" ww:@"w_weights"];
    
}

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
/* Loads the weights v[][] and w[][] */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
-(void)loadWeights:(NSString*)vw ww:(NSString*)ww{
    
    //read weights from NSUserDefaults
    NSMutableArray *v_weights = [[NSMutableArray alloc]initWithArray:[[NSUserDefaults standardUserDefaults]objectForKey:vw]];
    NSMutableArray *w_weights = [[NSMutableArray alloc]initWithArray:[[NSUserDefaults standardUserDefaults]objectForKey:ww]];
    int j,k,i;
    int l=0;
    int m=0;
    //NSLog(@"%@",v_weights);
    
    for(j=0;j<=hiddenNodes;j++)
    {
        for (k=0;k<outputNodes;k++)
        {
            w[j][k] = [[w_weights objectAtIndex:l]doubleValue];
            l++;
            //NSLog(@"w[%i][%i]=%.20f",j,k,w[j][k]);
        }
        for(i=0;i<=inputNodes;i++)
        {
            v[i][j] = [[v_weights objectAtIndex:m]doubleValue];
            m++;
        }
    }
}

-(void)testWeights{
    NSMutableArray *test_weights = [[NSMutableArray alloc]initWithArray:[[NSUserDefaults standardUserDefaults]objectForKey:@"test_weights"]];
    int j,i;
    double test[2][2];
    
    //INIT
    NSLog(@"INIT");
    for(j=0;j<2;j++)
    {
        for(i=0;i<2;i++)
        {
            test[i][j]= drand48();
        }
    }
    
    //PRINT
    for(j=0;j<2;j++)
    {
        for(i=0;i<2;i++)
        {
           NSLog(@"test_weights:%f",test[i][j]);
        }
    }
    
    //STORE
    NSLog(@"STORE");
    for(j=0;j<2;j++)
    {
        for(i=0;i<2;i++)
        {
            [test_weights addObject:[NSNumber numberWithDouble:test[i][j]]];
        }
    }
    [[NSUserDefaults standardUserDefaults]setObject:test_weights forKey:@"test_weights"];
 
    //LOAD
    NSLog(@"LOAD");
    NSMutableArray *test2_weights = [[NSMutableArray alloc]initWithArray:[[NSUserDefaults standardUserDefaults]objectForKey:@"test_weights"]];
    int k=0;
    for(j=0;j<2;j++)
    {
        for(i=0;i<2;i++)
        {
            test[i][j] = [[test2_weights objectAtIndex:k]doubleValue];
            k++;
        }
    }
    
    //PRINT
    for(j=0;j<2;j++)
    {
        for(i=0;i<2;i++)
        {
            NSLog(@"test_weights:%f",test[i][j]);
        }
    }
}

-(void)printWeights{
    int j,k,i;
    
    for(j=0;j<=hiddenNodes;j++)
    {
        for (k=0;k<outputNodes;k++)
        {
        
           // NSLog(@"w[%i][%i]=%f",j,k,w[j][k]);
        }
        for(i=0;i<=inputNodes;i++)
        {
           // NSLog(@"v[%i][%i]=%f",i,j,v[i][j]);

        }
    }
    for (j=0;j<hiddenNodes;j=j+10)
    {
        
        NSLog(@"w[%i][0]=%.20f",j,w[j][0]);
    }

}

-(void)storeWeights:(NSString*)vw ww:(NSString*)ww{
    NSMutableArray *v_weights = [[NSMutableArray alloc]init];
    NSMutableArray *w_weights = [[NSMutableArray alloc]init];
    
    int j,k,i;
    
    for(j=0;j<=hiddenNodes;j++)
    {
        for (k=0;k<outputNodes;k++)
        {
            [w_weights addObject:[NSNumber numberWithDouble:w[j][k]]];
        }
        for(i=0;i<=inputNodes;i++)
        {
            [v_weights addObject:[NSNumber numberWithDouble:v[i][j]]];
        }
    }
//NSLog(@"TEST=%@",w_weights);
    //save weights in NSUserDefaults
    [[NSUserDefaults standardUserDefaults]setObject:w_weights forKey:ww];
    [[NSUserDefaults standardUserDefaults]setObject:v_weights forKey:vw];
   //NSLog(@"%@",v_weights);
}

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
/* the forward propagation: computes
 hidden layer and output predictions  */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
-(double) Response:(double[])input{
        
    int i,j,k;
    hiddenNode[hiddenNodes]=BIAS;
    //inputNode[inputNodes]=BIAS;
    input[inputNodes]=BIAS;
    
    /*//TEST
    for(i=0;i<=inputNodes;i++){
        NSLog(@"input[%i]=%f",i,input[i]);
    }*/
    
    //calculate the hidden nodes' value using the sigmoid function
    for(j=0;j<hiddenNodes;j++)
    {
        hiddenNode[j]=0.0;
        for(i=0;i<=inputNodes;i++)
        {
            //hiddenNode[j]+=inputNode[i]*v[i][j];
            //NSLog(@"input[%i]=%f",i,input[i]);
            //NSLog(@"v[i][j]=%f",v[i][j]);
            hiddenNode[j]+=input[i]*v[i][j];
        }
        hiddenNode[j]=1.0/(1.0+ exp(-hiddenNode[j])); /* asymmetric sigmoid */
        //NSLog(@"HIDDEN %.20f",hiddenNode[j]);
    }
    
    //calculate the output nodes' value using the sigmoid function
    for(k=0;k<outputNodes;k++)
    {
        outputNode[k]=0.0;
        for(j=0;j<=hiddenNodes;j++)
        {
            outputNode[k]+=hiddenNode[j]*w[j][k];
            //NSLog(@"test %.20f",w[j][k]);
            //NSLog(@"OUTPUT %.20f",outputNode[k]);
        }
        outputNode[k]=1.0/(1.0+exp(-outputNode[k]));
    }

    //NSLog(@"OUTPUT2 %.20f",outputNode[0]);
    return outputNode[0];
}

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******
 * backpropagates the TD errors and updates the
 weights according to the error observed */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
-(void) TDlearn
{
    int i,j,k;
    for(k=0;k<outputNodes;k++)
    {
        for(j=0;j<=hiddenNodes;j++)
        {
            //NSLog(@"w=%f error[0]=%f,ew[%i][0]=%f",w[j][0],error[0],j,ew[j][0]);
            //NSLog(@"Z1=%.20f",BETA*error[k]*ew[j][k]);
            w[j][k]+=BETA*error[k]*ew[j][k]; //update the second layer weights
            for(i=0;i<=inputNodes;i++){
                v[i][j]+=ALPHA*error[k]*ev[i][j][k]; //update the first layer weights
            }
        }
    }
    
    //save current weights
    [self storeWeights:@"c_v" ww:@"c_w"];
    //load original ones for the next time
    //[self loadWeights:@"v_weights" ww:@"w_weights"];

}
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******
 * Updates the eligibility traces */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
-(void) UpdateElig:(double[])input
{
    int i,j,k;
    double temp[outputNodes];
    for(k=0;k<outputNodes;k++){
        temp[k]=outputNode[k]*(1-outputNode[k]);
        //temp[k]=1.0;
    }
    for(j=0;j<=hiddenNodes;j++)
    {
        for(k=0;k<outputNodes;k++)
        {
            ew[j][k]=LAMBDA*ew[j][k]+temp[k]*hiddenNode[j];
            for (i=0;i<=inputNodes;i++)
            {
                ev[i][j][k]=LAMBDA*ev[i][j][k]+temp[k]*w[j][k]*hiddenNode[j]*(1-hiddenNode[j])*input[i];
            }
        }
    }
}

// clears the arrays of the eligibility traces
-(void) clearEligTrace{
    for (int j=0;j<=hiddenNodes;j++){
        for (int k=0;k<outputNodes;k++){
            ew[j][k]=0.0;
        }
        for (int i=0;i<=inputNodes;i++){
            for (int k=0;k<outputNodes;k++){
                ev[i][j][k]=0.0;
            }
        }
    }
}

-(void) printEligTrace{
    /*for (int j=0;j<=hiddenNodes;j++){
        for (int k=0;k<outputNodes;k++){
            NSLog(@"%.20f",ew[j][k]);
        }
        for (int i=0;i<=inputNodes;i++){
            for (int k=0;k<outputNodes;k++){
                NSLog(@"%.20f",ev[i][j][k]);
            }
        }
    }*/
    NSLog(@"%.20f",ew[10][0]);
    NSLog(@"%.20f",ev[10][10][0]);
}

-(int)getInputNodes{
    return inputNodes;
}
-(int)getOutputNodes{
    return outputNodes;
}
-(void)setOutputNode:(double)val{
    outputNode[0]=val;
}
-(void)setReward:(double)val{
    reward[0]=val;
}
-(double)getReward{
    return reward[0];
}
-(double)getOutputNode{
    return outputNode[0];
    
}
-(double)getOldOutputNode{
    return oldOutputNode[0];
    
}
-(void)setOldOutputNode:(double)val{
    oldOutputNode[0]=val;
}
-(void)setError:(double)val{
    error[0]=val;
}
-(double)getError{
    return error[0];
    
}
-(double)getGamma{
    return GAMMA;
}
@end

//
//  Packet.m
//  ReinforcementLearningGame
//
//  Created by Zois Avgerinos on 9/25/13.
//  Copyright (c) 2013 Zois Avgerinos. All rights reserved.
//

#import "Packet.h"
#import "NSData+RLGMAdditions.h"
#import "PacketSignInResponse.h"
#import "PacketServerReady.h"
#import "PacketSendMove.h"
const size_t PACKET_HEADER_SIZE = 10;

@implementation Packet

@synthesize packetType = _packetType;


+ (id)packetWithType:(PacketType)packetType
{
	return [[[self class] alloc] initWithType:packetType];
}


- (id)initWithType:(PacketType)packetType
{
	if ((self = [super init]))
	{
        
		self.packetType = packetType;
	}
	return self;
}


- (NSData *)data
{
	NSMutableData *data = [[NSMutableData alloc] initWithCapacity:100];
    
	[data rw_appendInt32:'RLGM'];
	[data rw_appendInt32:0];
	[data rw_appendInt16:self.packetType];
    [self addPayloadToData:data];
	return data;
}

- (NSString *)description
{
	return [NSString stringWithFormat:@"%@, type=%d", [super description], self.packetType];
}

+ (id)packetWithData:(NSData *)data
{
	if ([data length] < PACKET_HEADER_SIZE)
	{
		NSLog(@"Error: Packet too small");
		return nil;
	}
    
	if ([data rw_int32AtOffset:0] != 'RLGM')
	{
		NSLog(@"Error: Packet has invalid header");
		return nil;
	}
    
	//int packetNumber = [data rw_int32AtOffset:4];
	PacketType packetType = [data rw_int16AtOffset:8];
    
	Packet *packet;
    
	switch (packetType)
	{
		case PacketTypeSignInRequest:
		case PacketTypeClientReady:
        case PacketTypeServerQuit:
		case PacketTypeClientQuit:
			packet = [Packet packetWithType:packetType];
			break;
            
		case PacketTypeSignInResponse:
			packet = [PacketSignInResponse packetWithData:data];
			break;
        case PacketTypeServerReady:
			packet = [PacketServerReady packetWithData:data];
			break;
        case PacketTypeMove:
			packet = [PacketSendMove packetWithData:data];
			break;
		default:
			NSLog(@"Error: Packet has invalid type");
			return nil;
	}
    
	return packet;
}
- (void)addPayloadToData:(NSMutableData *)data
{
	// base class does nothing
    
}
@end
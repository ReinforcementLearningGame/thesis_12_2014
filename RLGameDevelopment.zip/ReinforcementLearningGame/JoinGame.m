//
//  JoinGame.m
//  RL_Game
//
//  Created by Zois Avgerinos on 9/17/13.
//  Copyright 2013 Zois Avgerinos. All rights reserved.
//

#import "JoinGame.h"
#import "HelloWorldLayer.h"
#import "Server.h"
#import "Client.h"
#import "RLGameRun.h"

@implementation JoinGame{
    Client *_client;
    QuitReason _quitReason;
}
@synthesize joinLabel=_joinLabel;
@synthesize nameLabel=_nameLabel;
@synthesize connectingLabel=_connectingLabel;
@synthesize connectedLabel =_connectedLabel;
@synthesize name_Label=_name_Label;
@synthesize delegate=_delegate;



+(CCScene *) scene {
    CCScene *scene = [CCScene node];
    JoinGame *layer = [JoinGame node];
    [scene addChild: layer];
    return scene;
}

-(id)init{
    if( (self=[super init]) ) {
        //ask director for the window size
		CGSize winSize = [CCDirector sharedDirector].winSize;
        
        //MENU BUTTONS
        CCMenuItem *backToMenu = [CCMenuItemFont itemWithString:@"back" target:self selector:@selector(onStartBackPressed)];
        CCMenuItem *startJoin = [CCMenuItemFont itemWithString:@"join" target:self selector:@selector(onStartJoinPressed)];
        
        //Create the real Menu
        CCMenu *menu = [CCMenu menuWithItems:backToMenu,startJoin, nil];
        //position
        //menu.position = ccp(winSize.width * 0.5f, winSize.height * 0.4f);
        [menu setPosition:ccp( winSize.width/2 - 50, winSize.height/2 - 130)];
        //alignment
        //[menu alignItemsVerticallyWithPadding:15];
        [menu alignItemsHorizontallyWithPadding:20];
        //Add the menu as a child to this layer
        [self addChild:menu];
        
        //TOP LABEL
        _joinLabel = [CCLabelTTF labelWithString:@"JOIN Game" fontName:@"Marker Felt" fontSize:64];
        _joinLabel.position =  ccp( winSize.width /2 , winSize.height/2+100 );
        // add the label as a child to this Layer
        [self addChild: _joinLabel];
        
        //NAME LABEL
        _name_Label = [CCLabelTTF labelWithString:@"Name:" fontName:@"Marker Felt" fontSize:32];
        _name_Label.position =  ccp( 50, winSize.height/2+20 );
        // add the label as a child to this Layer
        [self addChild: _name_Label];
        _nameLabel = [CCLabelTTF labelWithString:@"Name:" fontName:@"Marker Felt" fontSize:16];
        _nameLabel.anchorPoint=ccp(0,1);
        _nameLabel.position =  ccp( 100 , winSize.height/2+30 );
        // add the label as a child to this Layer
        [self addChild: _nameLabel];
        
        //CONNECTING LABEL
        _connectingLabel = [CCLabelTTF labelWithString:@"Server:" fontName:@"Marker Felt" fontSize:32];
        _connectingLabel.position =  ccp( 55, winSize.height/2-20 );
        // add the label as a child to this Layer
        [self addChild: _connectingLabel];
        
        //CONNECTED LABEL
        _connectedLabel = [CCLabelTTF labelWithString:@"" fontName:@"Marker Felt" fontSize:16];
        _connectedLabel.anchorPoint=ccp(0,1);
        _connectedLabel.position =  ccp( 110, winSize.height/2-10 );
        // add the label as a child to this Layer
        [self addChild: _connectedLabel];
        
        
        //enable touches
        self.touchEnabled = YES;
        
        //CLIENT
        
        if (_client == nil)
        {
            _quitReason = QuitReasonConnectionDropped;
            
            _client = [[[Client alloc] init]retain];
            _client.delegate=self;
            [_client startSearchingForServersWithSessionID:SESSION_ID];
            
            [_nameLabel setString:[NSString stringWithFormat:@"%@",_client.session.displayName]];
            //[self.tableView reloadData];
        }
        
    }
    return self;
}

- (void)matchmakingClient:(Client *)client serverBecameAvailable:(NSString *)peerID
{
	//[_connectedLabel setString:[_client peerIDForAvailableServerAtIndex:0]];
    [_connectedLabel setString:[_client displayNameForPeerID:peerID]];
}

- (void)matchmakingClient:(Client *)client serverBecameUnavailable:(NSString *)peerID
{
	[_connectedLabel setString:@""];
}

- (void)matchmakingClient:(Client *)client didDisconnectFromServer:(NSString *)peerID
{
	_client.delegate = nil;
	_client = nil;
	[_connectedLabel setString:@""];
    
    //alert disconnection
    [self showDisconnectedAlert];
    
    CCScene *MainMenuScene = [HelloWorldLayer scene];
    [[CCDirector sharedDirector] replaceScene:[CCTransitionJumpZoom transitionWithDuration:0.5f scene:MainMenuScene]];
    
	//[self.delegate joinViewController:self didDisconnectWithReason:_quitReason];
    
}

-(void)onStartJoinPressed{
    if(_client !=nil &&  [_client availableServerCount] > 0){
    NSString *peerID = [_client peerIDForAvailableServerAtIndex:0];
    
    [_client connectToServerWithPeerID:peerID];
        
    }
}

-(void)onStartBackPressed{
    _quitReason = QuitReasonUserQuit;
	[_client disconnectFromServer];
  
    CCScene *MainMenuScene = [HelloWorldLayer scene];
    [[CCDirector sharedDirector] replaceScene:[CCTransitionJumpZoom transitionWithDuration:0.5f scene:MainMenuScene]];
    
}

- (void)showDisconnectedAlert
{
	UIAlertView *alertView = [[UIAlertView alloc]
                              initWithTitle:NSLocalizedString(@"Disconnected", @"Client disconnected alert title")
                              message:NSLocalizedString(@"You were disconnected from the game.", @"Client disconnected alert message")
                              delegate:nil
                              cancelButtonTitle:NSLocalizedString(@"OK", @"Button: OK")
                              otherButtonTitles:nil];
    
	[alertView show];
}

- (void)matchmakingClientNoNetwork:(Client *)client
{
	_quitReason = QuitReasonNoNetwork;
}

- (void)matchmakingClient:(Client *)client didConnectToServer:(NSString *)peerID
{
	NSString *name = [[_nameLabel string] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	if ([name length] == 0)
		name = _client.session.displayName;
    
	//[self.delegate joinViewController:self startClientGameWithSession:_client.session playerName:name server:peerID];
 
    //start game
    
    [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:0.5f scene:[RLGameRun sceneClientWithParams:_client.session playerName:name server:peerID]]];
}


@end

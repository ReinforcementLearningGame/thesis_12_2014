//
//  Pawn.m
//  RL_Game
//
//  Created by Zois Avgerinos on 8/30/13.
//  Copyright 2013 Zois Avgerinos. All rights reserved.
//

#import "Pawn.h"


@implementation Pawn

@synthesize pawnSprite;
@synthesize type;
@synthesize isInBase;

@end

//
//  HostGame.h
//  RL_Game
//
//  Created by Zois Avgerinos on 9/16/13.
//  Copyright 2013 Zois Avgerinos. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "Server.h"

@class HostGame;
@protocol HostGameDelegate <NSObject>

- (void)hostViewController:(HostGame *)controller didEndSessionWithReason:(QuitReason)reason;

@end


@interface HostGame : CCLayer<ServerDelegate> {
    
}
@property (nonatomic, strong) IBOutlet CCLabelTTF *hostLabel;
@property (nonatomic, strong) IBOutlet CCLabelTTF *nameLabel;
@property (nonatomic, strong) IBOutlet CCLabelTTF *name_Label;
@property (nonatomic, strong) IBOutlet CCLabelTTF *connectingLabel;
@property (nonatomic, strong) IBOutlet CCLabelTTF *connectedLabel;
@property (nonatomic, strong) id <HostGameDelegate> delegate;
+(CCScene *) scene;
@end

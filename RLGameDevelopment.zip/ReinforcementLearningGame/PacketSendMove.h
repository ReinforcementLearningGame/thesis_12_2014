//
//  PacketSendMove.h
//  ReinforcementLearningGame
//
//  Created by Zois Avgerinos on 9/28/13.
//  Copyright (c) 2013 Zois Avgerinos. All rights reserved.
//

#import "Packet.h"

@interface PacketSendMove : Packet

@property (nonatomic, copy) NSString *endTag;
@property (nonatomic, copy) NSString *pawnTag;
@property (nonatomic, copy) NSString *eliminate;
@property (nonatomic, copy) NSString *startTag;
+ (id)packetWithEndTagAndPawn:(NSString *)endTag pawn:(NSString *)pawnTag eliminate:(NSString *)eliminate starttag:(NSString *)startTag;

@end

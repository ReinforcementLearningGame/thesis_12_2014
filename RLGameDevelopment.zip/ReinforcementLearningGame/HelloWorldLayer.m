//
//  HelloWorldLayer.m
//  RL_Game
//
//  Created by Zois Avgerinos on 8/27/13.
//  Copyright Zois Avgerinos 2013. All rights reserved.
//


// Import the interfaces
#import "HelloWorldLayer.h"
#import "RLGameRun.h"
#import "HostGame.h"
#import "JoinGame.h"


// Needed to obtain the Navigation Controller
#import "AppDelegate.h"

#pragma mark - HelloWorldLayer

// HelloWorldLayer implementation
@implementation HelloWorldLayer

// Helper class method that creates a Scene with the HelloWorldLayer as the only child.
+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	HelloWorldLayer *layer = [HelloWorldLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
-(id) init
{
	// always call "super" init
	// Apple recommends to re-assign "self" with the "super's" return value
	if( (self=[super init]) ) {
		
        //ask director for the window size
		CGSize winSize = [CCDirector sharedDirector].winSize;
        //Initialize a CCSprite with the backgruound picture we want to load
        CCSprite *backgroundImage = [CCSprite spriteWithFile:@"WoodRetroApple_iPad_HomeScreen.jpg"];
        //center the image
        backgroundImage.position = ccp(winSize.width/2, winSize.height/2);
        //Add the CCSprite to the scene
        [self addChild:backgroundImage z:-2];
        
        //add a label title
        CCLabelTTF *label = [CCLabelTTF labelWithString:@"RL Game" fontName:@"Marker Felt" fontSize:64];
        // position the label on the center of the screen
        label.position =  ccp( winSize.width /2 , winSize.height/2 );
        // add the label as a child to this Layer
        [self addChild: label];
        
        //or you can Add a logo as a title
        /*CCSprite *logo = [CCSprite spriteWithFile:@"MonsterSmashing.png"];
         logo.scale = 1.2;
         logo.position =  ccp(winSize.width /2 , winSize.height/2 );
         [self addChild: logo];*/
        
        //Menu Items
        //using images
        //CCMenuItem *startGameButtonImage = [CCMenuItemImage itemWithNormalImage:@"playButton.png" selectedImage:@"playButtonSelected.png" target:self selector:@selector(onStartGamePressed)];
        //using fonts
        CCMenuItem *startGameButtonFont = [CCMenuItemFont itemWithString:@"play" target:self selector:@selector(onStartGamePressed)];
        CCMenuItem *hostGame = [CCMenuItemFont itemWithString:@"host" target:self selector:@selector(onStartHostPressed)];
        CCMenuItem *joinGame = [CCMenuItemFont itemWithString:@"join" target:self selector:@selector(onStartJoinPressed)];
        
        /*sound buttons with images
        CCMenuItem *_soundOn = [[CCMenuItemImage  itemWithNormalImage:@"soundOn.png"
                                                        selectedImage:@"soundOnSelected.png" target:nil selector:nil] retain];
        CCMenuItem *_soundOff = [[CCMenuItemImage itemWithNormalImage:@"soundOff.png"
                                                        selectedImage:@"soundOffSelected.png" target:nil selector:nil] retain];
         */
        CCMenuItem *_audioOn = [CCMenuItemFont itemWithString:@"sound on" target:self selector:nil];
        CCMenuItem *_audioOff = [CCMenuItemFont itemWithString:@"sound off" target:self selector:nil];
        
        //toggle two states for the sound, on and off
        CCMenuItemToggle *toggleItem = [CCMenuItemToggle itemWithTarget:self
                                                               selector:@selector(soundButtonTapped:) items:_audioOn, _audioOff, nil];
        //Create the real Menu
        CCMenu *menu = [CCMenu menuWithItems:startGameButtonFont, hostGame, joinGame, toggleItem, nil];
        //position
        //menu.position = ccp(winSize.width * 0.5f, winSize.height * 0.4f);
        [menu setPosition:ccp( winSize.width/2, winSize.height/2 - 100)];
        //alignment
        //[menu alignItemsVerticallyWithPadding:15];
        [menu alignItemsHorizontallyWithPadding:20];
        //Add the menu as a child to this layer
        [self addChild:menu];
        
        //enable touches
        self.touchEnabled = YES;
        
	}
	return self;
}

-(void)ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    //grab any touch
    UITouch *touch = [touches anyObject];
    CGPoint location = [touch locationInView:[touch view]];
    location = [[CCDirector sharedDirector]convertToGL:location];
    CCLOG(@"touch happened at x:%0.2f, y:%0.2f",location.x,location.y);
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	
	// don't forget to call "super dealloc"
	[super dealloc];
}

-(void)onStartHostPressed{
    CCScene *HostGameScene = [HostGame scene];
    [[CCDirector sharedDirector] replaceScene:[CCTransitionJumpZoom transitionWithDuration:0.5f scene:HostGameScene]];
}

-(void)onStartJoinPressed{
    CCScene *JoinGameScene = [JoinGame scene];
    [[CCDirector sharedDirector] replaceScene:[CCTransitionJumpZoom transitionWithDuration:0.5f scene:JoinGameScene]];
}

//sound on/off
- (void)soundButtonTapped:(id)sender {
    // TODO
}

//load the new RLGameRun scene
- (void)onStartGamePressed {
    CCScene *RLGameRunScene = [RLGameRun scene];
    //CCTransitionFlipAngular *transition = [CCTransitionFlipAngular transitionWithDuration:0.5f scene:HelloWorldLayerScene];
    [[CCDirector sharedDirector] replaceScene:[CCTransitionJumpZoom transitionWithDuration:0.5f scene:RLGameRunScene]];
}


#pragma mark GameKit delegate

-(void) achievementViewControllerDidFinish:(GKAchievementViewController *)viewController
{
	AppController *app = (AppController*) [[UIApplication sharedApplication] delegate];
	[[app navController] dismissViewControllerAnimated:YES completion:NULL];
}

-(void) leaderboardViewControllerDidFinish:(GKLeaderboardViewController *)viewController
{
	AppController *app = (AppController*) [[UIApplication sharedApplication] delegate];
	[[app navController] dismissViewControllerAnimated:YES completion:NULL];
}


//METHODS IF MAIN SCREEN DELEGATES HOST AND JOIN SCREENS
- (void)joinViewController:(JoinGame *)controller didDisconnectWithReason:(QuitReason)reason
{
	if (reason == QuitReasonNoNetwork)
	{
		[self showNoNetworkAlert];
	}
	else if (reason == QuitReasonConnectionDropped)
	{
		
             [self showDisconnectedAlert];
       
	}
}

- (void)hostViewController:(HostGame *)controller didEndSessionWithReason:(QuitReason)reason
{
	if (reason == QuitReasonNoNetwork)
	{
		[self showNoNetworkAlert];
	}
}

- (void)showDisconnectedAlert
{
	UIAlertView *alertView = [[UIAlertView alloc]
                              initWithTitle:NSLocalizedString(@"Disconnected", @"Client disconnected alert title")
                              message:NSLocalizedString(@"You were disconnected from the game.", @"Client disconnected alert message")
                              delegate:nil
                              cancelButtonTitle:NSLocalizedString(@"OK", @"Button: OK")
                              otherButtonTitles:nil];
    
	[alertView show];
}

- (void)showNoNetworkAlert
{
	UIAlertView *alertView = [[UIAlertView alloc]
                              initWithTitle:NSLocalizedString(@"No Network", @"No network alert title")
                              message:NSLocalizedString(@"To use multiplayer, please enable Bluetooth or Wi-Fi in your device's Settings.", @"No network alert message")
                              delegate:nil
                              cancelButtonTitle:NSLocalizedString(@"OK", @"Button: OK")
                              otherButtonTitles:nil];
    
	[alertView show];
}
@end

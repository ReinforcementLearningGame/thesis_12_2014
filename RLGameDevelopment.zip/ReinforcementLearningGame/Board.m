//
//  Board.m
//  RL_Game
//
//  Created by Zois Avgerinos on 9/5/13.
//  Copyright 2013 Zois Avgerinos. All rights reserved.
//

#import "Board.h"
#import "Square.h"
#import "Pawn.h"
#import "Constants.h"

NSMutableArray *_squares;
NSMutableArray *_pawns;

@implementation Board

-(id)init{
    self.touchEnabled = YES;
    if( (self=[super init]) ) {
    //initialize squares
    _squares = [[NSMutableArray alloc]init];
    //initialize pawns
    _pawns = [[NSMutableArray alloc]init];
    
    //simple square
    Square *s = [[Square alloc]init];
    //tag
    //[s setTag:1];
    //square image file
    [s setSquareSprite:@"square.png"];
    
    //base squares
    Square *sba = [[Square alloc]init];
    Square *sbb = [[Square alloc]init];
    [sba setSquareSprite:@"squarebasea.png"];
    [sbb setSquareSprite:@"squarebaseb.png"];
    
    //add to _squares array
    [_squares addObject:s];
    [_squares addObject:sba];
    [_squares addObject:sbb];
    
    //initialize pawns
    Pawn *px = [[Pawn alloc]init];
    [px setPawnSprite:@"xpawn64.png"];
    Pawn *po = [[Pawn alloc]init];
    [po setPawnSprite:@"opawn64.png"];
    
    [_pawns addObject:px];
    [_pawns addObject:po];
    
    //show them
    //[self addPawns];
    //[self addSquares];
    }
    return self;
}



-(void)addPawns:(CCLayer *)layer{
    
    //get type of pawns
    Pawn *px = [_pawns objectAtIndex:0];
    Pawn *po = [_pawns objectAtIndex:1];
    
    for (int i=0; i<PAWNS_NUMBER; i++) {
        
        
        Pawn *pawnx = [Pawn spriteWithFile:[px pawnSprite]];
        Pawn *pawno = [Pawn spriteWithFile:[po pawnSprite]];
        pawnx.tag = 100+i; //create unique tags
        pawno.tag = 200+i;
        
        //they are inside the base first time
        pawnx.isInBase = YES;
        pawno.isInBase = YES;
        
        pawnx.type = @"X";
        pawno.type = @"O";
        
        pawnx.position = ccp(i+pawnx.contentSize.width,i+pawnx.contentSize.width);
        pawno.position = ccp((0.1*i+pawno.contentSize.width)*BOARD,(0.1*i+pawno.contentSize.width)*BOARD);
        
        [layer addChild:pawnx];
        [layer addChild:pawno];
        
        
    }
    
    /*TEST POSITIONS
    Pawn *testpawn =[Pawn spriteWithFile:[po pawnSprite]];
    testpawn.tag=999;
    testpawn.isInBase=NO;
    testpawn.type=@"O";
    testpawn.position=ccp(25,95);
    [layer addChild:testpawn];
    */
}

-(void)addSquares:(CCLayer *)layer{
    Square *s = [_squares objectAtIndex:0];
    Square *sba = [_squares objectAtIndex:1];
    Square *sbb = [_squares objectAtIndex:2];
    
    //set squares
    int k=0;  //for creating unique tags
    for (int i=0; i<BOARD; i++) {
        for (int j=0; j<BOARD; j++) {
            Square *square;
            if ((i==0 && j==0) || (i==0 && j==BASE -1) || (i==BASE -1 && j==0) || (i==BASE -1 && j==BASE -1)) {
                square = [Square spriteWithFile:[sba squareSprite]];
                square.tag = k;
                
                
            } else if ((i==BOARD-BASE && j==BOARD-BASE) || (i==BOARD-BASE && j==BOARD-1) || (i==BOARD-1 && j==BOARD-BASE) || (i==BOARD-1 && j==BOARD-1)) {
                square = [Square spriteWithFile:[sbb squareSprite]];
                square.tag = k;
                
            } else {
                square = [Square spriteWithFile:[s squareSprite]];
                square.tag = k;
                
            }
            k++;
            
            square.position = ccp(((square.contentSize.width+SQUARE_MARGIN)*i)+WINDOW_MARGIN,((square.contentSize.width+SQUARE_MARGIN)*j)+WINDOW_MARGIN);
            
            square.xcoord = i;
            square.ycoord = j;
            square.isOccuppied = NO;
            square.havePawn = -1;
            [layer addChild:square z:-1];
            
            /*TESTING
            //add a label title
            CCLabelTTF *label = [CCLabelTTF labelWithString:[NSString stringWithFormat:@"%i\n%i,%i",square.tag,square.xcoord,square.ycoord] fontName:@"Marker Felt" fontSize:12];
            // position the label on the center of the screen
            label.position =  ccp(((square.contentSize.width+SQUARE_MARGIN)*i)+WINDOW_MARGIN,((square.contentSize.width+SQUARE_MARGIN)*j)+WINDOW_MARGIN);
            // add the label as a child to this Layer
            [layer addChild: label];
            
            *********/
            
        }
    }
    
}

//calculate base squares
+(NSMutableArray *)calcBaseSquares{
    NSMutableArray *array = [[NSMutableArray alloc]init];
    //BOTTOM BASE
    for (int i=0; i<BASE; i++) {
        int t=i+BOARD;
        [array addObject:[NSNumber numberWithInt:i]];
        [array addObject:[NSNumber numberWithInt:t]];
    }
   //TOP BASE
    for (int i=BOARD*BOARD-1; i>BOARD*BOARD-1-BASE; i--) {
        int t=i-BOARD;
        [array addObject:[NSNumber numberWithInt:i]];
        [array addObject:[NSNumber numberWithInt:t]];
    }
    
    /*TEST THAT
     for (NSNumber *n in array) {
     NSLog(@"base=%i",[n intValue]);
     }*/
     
    return [array autorelease];
}

//calculate the adjacent to a base squares
+(NSMutableArray *)calcAdjSquares{
    
    NSMutableArray *array = [[NSMutableArray alloc]init];
    
    //BOTTOM BASE ADJACENT SQUARES
    for (int i=0; i<=BASE; i++) {
        int t=BASE+BOARD*i;
        [array addObject:[NSNumber numberWithInt:t]];
    }
    for (int i=BASE;i>=1;i--){
        int t=BASE-i+BASE*BOARD;
        [array addObject:[NSNumber numberWithInt:t]];
    }
    
    //TOP BASE ADJACENT SQUARES
    for (int i=0; i<BASE; i++) {
        int t = ((BOARD*BOARD)-BASE-1)-BOARD*i;
        [array addObject:[NSNumber numberWithInt:t]];
    }
    for (int i=0; i<=BASE; i++) {
        int t = (BOARD*BOARD)-1-(BASE*BOARD)-i;
        [array addObject:[NSNumber numberWithInt:t]];
        
    }
    
    /*TEST THAT
     for (NSNumber *n in array) {
     NSLog(@"adj=%i",[n intValue]);
     }
     */
    
    return [array autorelease];
}


@end

//
//  PacketSendMove.m
//  ReinforcementLearningGame
//
//  Created by Zois Avgerinos on 9/28/13.
//  Copyright (c) 2013 Zois Avgerinos. All rights reserved.
//

#import "PacketSendMove.h"
#import "NSData+RLGMAdditions.h"

@implementation PacketSendMove

@synthesize endTag = _endTag;
@synthesize pawnTag = _pawnTag;
@synthesize eliminate=_eliminate;

+ (id)packetWithEndTagAndPawn:(NSString *)endTag pawn:(NSString *)pawnTag eliminate:(NSString *)eliminate starttag:(NSString *)startTag
{
	return [[[self class] alloc] initWithEndTagAndPawn:endTag pawn:pawnTag eliminate:eliminate starttag:startTag];
}


+ (id)packetWithData:(NSData *)data
{
	size_t count;
    size_t offset = PACKET_HEADER_SIZE;
    
	NSString *endTag = [data rw_stringAtOffset:offset bytesRead:&count];
    offset += count;
    NSString *pawnTag = [data rw_stringAtOffset:offset bytesRead:&count];
    offset += count;
    NSString *eliminate = [data rw_stringAtOffset:offset bytesRead:&count];
    offset += count;
    NSString *startTag = [data rw_stringAtOffset:offset bytesRead:&count];
    
	return [[self class] packetWithEndTagAndPawn:endTag pawn:pawnTag eliminate:eliminate starttag:startTag];
}


- (id)initWithEndTagAndPawn:(NSString *)endTag pawn:(NSString *)pawnTag eliminate:(NSString *)eliminate starttag:(NSString *)startTag
{
	if ((self = [super initWithType:PacketTypeMove]))
	{
		self.endTag = endTag;
        self.pawnTag = pawnTag;
        self.eliminate = eliminate;
        self.startTag = startTag;
	}
	return self;
}

- (void)addPayloadToData:(NSMutableData *)data
{
	[data rw_appendString:self.endTag];
    [data rw_appendString:self.pawnTag];
    [data rw_appendString:self.eliminate];
    [data rw_appendString:self.startTag];
}

@end

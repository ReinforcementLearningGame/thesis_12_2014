//
//  RLGameRun.h
//  RL_Game
//
//  Created by Zois Avgerinos on 8/29/13.
//  Copyright 2013 Zois Avgerinos. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <GameKit/GameKit.h>
#import "cocos2d.h"
#import "HelloWorldLayer.h"
#import "Pawn.h"
#import "Board.h"

@interface RLGameRun : CCLayer <GKSessionDelegate,GKPeerPickerControllerDelegate>{
    Pawn *currentPawn;
    CCMenuItem *pauseButton;
    CCMenuItem *resumeButton;
    
    //position when touch began
    //as location
    int touchstartx;
    int touchstarty;
    //as coordinates
    int startposx;
    int startposy;
    int starttag;
    
    //pawns left
    int remainingX;
    int remainingO;
    CCLabelTTF *Xlabelvalue;
    CCLabelTTF *Olabelvalue;
    BOOL XbaseEmpty;
    BOOL ObaseEmpty;
    
    //play turn
    BOOL XcanPlay;  //X plays first
    BOOL OcanPlay;
    //check if we indeed moved
    BOOL weMoved;
    
    UIAlertView *resetGameAlert;
    UIAlertView *disconnectedAlertView;
    UIAlertView *gameOverMoveAlert;

}
@property (nonatomic, assign) BOOL isServer;

- (void)startClientGameWithSession:(GKSession *)session playerName:(NSString *)name server:(NSString *)peerID;
- (void)startServerGameWithSession:(GKSession *)session playerName:(NSString *)name client:(NSArray *)client;
- (void)quitGameWithReason:(QuitReason)reason;

+(CCScene *) scene;
+(CCScene *) sceneClientWithParams:(GKSession *)session playerName:(NSString *)name server:(NSString *)peerID;
+(CCScene *) sceneServerWithParams:(GKSession *)session playerName:(NSString *)name client:(NSArray *)connectedClients;

@end

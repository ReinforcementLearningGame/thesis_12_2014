//
//  Constants.h
//  RL_Game
//
//  Created by Zois Avgerinos on 9/2/13.
//  Copyright (c) 2013 Zois Avgerinos. All rights reserved.
//

#import <Foundation/Foundation.h>

//dimensions
#define BOARD 8
#define BASE 2

#define PAWNS_NUMBER 10

#define WIN 1
#define LOSS 0

#define WINDOW_MARGIN 25
#define SQUARE_MARGIN 5
#define SQUARE 30
#define HIDDEN_SIZE BOARD*BOARD-2*BASE*BASE+5

@interface Constants : NSObject

@end

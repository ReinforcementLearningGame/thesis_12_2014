//
//  Board.h
//  RL_Game
//
//  Created by Zois Avgerinos on 9/5/13.
//  Copyright 2013 Zois Avgerinos. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "Square.h"
#import "Pawn.h"
@interface Board : CCLayer {
   
}
+(NSMutableArray *)calcAdjSquares;
+(NSMutableArray *)calcBaseSquares;
-(void)addPawns:(CCLayer *)layer;
-(void)addSquares:(CCLayer *)layer;

@end

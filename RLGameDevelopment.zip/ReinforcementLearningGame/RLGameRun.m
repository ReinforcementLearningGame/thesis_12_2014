//
//  RLGameRun.m
//  RL_Game
//
//  Created by Zois Avgerinos on 8/29/13.
//  Copyright 2013 Zois Avgerinos. All rights reserved.
//

#import "RLGameRun.h"
#import "Square.h"
#import "Pawn.h"
#import "Constants.h"
#import "Board.h"
#import "Packet.h"
#import "PacketSignInResponse.h"
#import "Player.h"
#import "PacketServerReady.h"
#import "NSData+RLGMAdditions.h"
#import "PacketSendMove.h"
#import "NeuralNet.h"

typedef enum
{
	GameStateWaitingForSignIn,
	GameStateWaitingForReady,
	//GameStateReady,
	GameStatePlaying,
	GameStateGameOver,
	GameStateQuitting,
}
GameState;

@implementation RLGameRun{
    GameState _state;
    
	GKSession *_session;
	NSString *_serverPeerID;
	NSString *_localPlayerName;
    
    NSMutableDictionary *_players;
    
    UIAlertView *_alertView;
    
    NeuralNet *net;
}

@synthesize isServer = _isServer;

NSMutableDictionary *centers;
NSMutableArray *adjSquareTags;
NSMutableArray *baseSquareTags;
NSMutableArray *obasesquares;
NSMutableDictionary *possibleValidMovesDict;
NSMutableArray *possibleValidMoves;
BOOL canReset = YES;
NSInteger end_tag;
NSString *whoWon;
NSString *whoLost;
CCLabelTTF *statuslabel;
BOOL server_client_moved = YES;
BOOL P2P = NO;
BOOL CHECK_FIRST=NO;
BOOL ZOMBIE =NO;
//NEURAL input
double input[2*HIDDEN_SIZE+1];
NSNumber *chosen_move;
double price;
double response;

-(void)setGlobals{
    //position when touch began
    //as location
    touchstartx=0;
    touchstarty=0;
    //as coordinates
    startposx=0;
    startposy=0;
    starttag=0;
    
    //pawns left
    remainingX = PAWNS_NUMBER;
    remainingO = PAWNS_NUMBER;
    
    XbaseEmpty=NO;
    ObaseEmpty=NO;
    
    //play turn
    XcanPlay = YES;  //X plays first
    OcanPlay = NO;
    //check if we indeed moved
    weMoved = YES;
    
    P2P = NO;
    CHECK_FIRST = NO;
    server_client_moved = YES;
}

+(CCScene *) scene {
    CCScene *scene = [CCScene node];
    RLGameRun *layer = [RLGameRun node];
    
    
    [scene addChild: layer];
    
    return scene;
}
//call with parameters
+(CCScene *) sceneClientWithParams:(GKSession *)session playerName:(NSString *)name server:(NSString *)peerID
{
    
    
    CCScene *scene = [CCScene node];
    RLGameRun *layer = [RLGameRun node];
    [layer startClientGameWithSession:session playerName:name server:peerID];
    //initialize stuff
    canReset = NO;
    P2P=YES;
    CCLabelTTF *scoreXLabel = [CCLabelTTF labelWithString:@"O-player" fontName:@"Marker Felt" fontSize:24];
    scoreXLabel.position=ccp(50,305);
    // add the label as a child to this Layer
    [layer addChild:scoreXLabel z:-1];
    //layer.touchEnabled=NO;
    [scene addChild: layer];
    return scene;
    
}

+(CCScene *) sceneServerWithParams:(GKSession *)session playerName:(NSString *)name client:(NSArray *)connectedClients{
    CCScene *scene = [CCScene node];
    RLGameRun *layer = [RLGameRun node];
    [layer startServerGameWithSession:session playerName:name client:connectedClients];
    //initialize stuff
    canReset = NO;
    P2P=YES;
    CCLabelTTF *scoreXLabel = [CCLabelTTF labelWithString:@"X-player" fontName:@"Marker Felt" fontSize:24];
    scoreXLabel.position=ccp(50,305);
    // add the label as a child to this Layer
    [layer addChild:scoreXLabel z:-1];
    //layer.touchEnabled=NO;
    [scene addChild: layer];
    return scene;
    
}

-(id)init {
    if( (self=[super init]) ) {
        self.TouchEnabled = YES;
        
        //load board and labels
        [self initializeGame];
        
        //init players
        _players = [[NSMutableDictionary dictionaryWithCapacity:4]retain];
        
        //we need this to get the square a pawn lies on
        [self calculateSquareCenters];
        [Board calcBaseSquares];
        
        if (!P2P){
            //Neural Network init
            net = [[NeuralNet alloc]init];
            //test loading/storing weights
            //[net testWeights];
            
            [net initWithParams:2 :2*HIDDEN_SIZE :HIDDEN_SIZE :1 :0.5 :0.7];
            
            //[net printEligTrace];
        }
        
    }
    return self;
}


-(void)initializeGame{
    //reset
    [self setGlobals];
    //ask director for the window size
    CGSize winSize = [CCDirector sharedDirector].winSize;
    //Initialize a CCSprite with the backgruound picture we want to load
    CCSprite *backgroundImage = [CCSprite spriteWithFile:@"WoodRetroApple_iPad_HomeScreen.jpg"];
    //center the image
    backgroundImage.position = ccp(winSize.width/2, winSize.height/2);
    //Add the CCSprite to the scene
    [self addChild:backgroundImage z:-2];
    
    CCSprite *bckframe = [CCSprite spriteWithFile:@"bckframe1-590x590.png"];
    //use anchorpoint. It means the point in the sprite itself used for positioning
    //this point will go into the position you specify
    //(0,0)=down left,(0.5,0.5)=center
    bckframe.anchorPoint=ccp(0,0);
    [self addChild:bckframe z:-1];
    CCSprite *bckframe2 = [CCSprite spriteWithFile:@"bckframe2-360x590.png"];
    //use anchorpoint.(1,0)=down right
    bckframe2.anchorPoint=ccp(1,0);
    bckframe2.position=ccp(480,0);
    [self addChild:bckframe2 z:-1];
    
    //Some labels
    /*
     CCLabelTTF *scoreOLabel = [CCLabelTTF labelWithString:@"Score O:" fontName:@"Marker Felt" fontSize:24];
     scoreOLabel.position=ccp(260,305);
     // add the label as a child to this Layer
     [self addChild:scoreOLabel z:-1];
     */
    
    //LOAD BOARD
    Board *board = [Board node];
    [board addSquares:self];
    [board addPawns:self];
    
    //pawn counter
    CCLabelTTF *Xlabel = [CCLabelTTF labelWithString:@"X" fontName:@"Marker Felt" fontSize:24];
    Xlabel.position =  ccp(320,50);
    // add the label as a child to this Layer
    [self addChild: Xlabel];
    Xlabelvalue = [CCLabelTTF labelWithString:[NSString stringWithFormat:@"%i",remainingX] fontName:@"Marker Felt" fontSize:24];
    Xlabelvalue.position =  ccp(320,20);
    // add the label as a child to this Layer
    [self addChild: Xlabelvalue];
    CCLabelTTF *Olabel = [CCLabelTTF labelWithString:@"O" fontName:@"Marker Felt" fontSize:24];
    Olabel.position =  ccp(350,50);
    // add the label as a child to this Layer
    [self addChild: Olabel];
    Olabelvalue = [CCLabelTTF labelWithString:[NSString stringWithFormat:@"%i",remainingO] fontName:@"Marker Felt" fontSize:24];
    Olabelvalue.position =  ccp(350,20);
    // add the label as a child to this Layer
    [self addChild: Olabelvalue];
    
    //LOAD ACTIONS MENU
    [self actionsMenu];
    
    //get base square tags
    baseSquareTags = [[NSMutableArray alloc]initWithArray:[Board calcBaseSquares]];
    
    //"O"'s own base squares
    obasesquares = [[NSMutableArray alloc]init];
    for (int i=BASE*BASE; i<2*BASE*BASE; i++) {
        [obasesquares addObject:[baseSquareTags objectAtIndex:i]];
    }
}

-(void)actionsMenu{
    //Menu Items
    CCMenuItem *resetGameActions = [CCMenuItemFont itemWithString:@"restart" target:self selector:@selector(resetGame)];
    CCMenuItem *backToMenu = [CCMenuItemFont itemWithString:@"menu" target:self selector:@selector(goMenu)];
    pauseButton = [[CCMenuItemImage  itemWithNormalImage:@"pause72.png"
                                           selectedImage:@"pause96.png" target:nil selector:nil] retain];
    resumeButton = [[CCMenuItemImage itemWithNormalImage:@"play_resume72.png"
                                           selectedImage:@"play_resume96.png" target:nil selector:nil] retain];
    //toggle two states for pause/resume
    CCMenuItemToggle *toggleActionItem = [CCMenuItemToggle itemWithTarget:self
                                                                 selector:@selector(pauseButtonTapped:) items:pauseButton, resumeButton, nil];
    //Create the real Menu
    CCMenu *menu = [CCMenu menuWithItems:resetGameActions,backToMenu, toggleActionItem, nil];
    //position
    //menu.position = ccp(winSize.width * 0.5f, winSize.height * 0.4f);
    [menu setPosition:ccp(400,220)];
    //alignment
    [menu alignItemsVerticallyWithPadding:15];
    //[menu alignItemsHorizontallyWithPadding:20];
    //Add the menu as a child to this layer
    [self addChild:menu];
}




- (void)startClientGameWithSession:(GKSession *)session playerName:(NSString *)name server:(NSString *)peerID
{
    CGSize winSize = [CCDirector sharedDirector].winSize;
    
    self.isServer = NO;
    
	_session = session;
	_session.available = NO;
	_session.delegate = self;
	[_session setDataReceiveHandler:self withContext:nil];
    
	_serverPeerID = peerID;
	_localPlayerName = name;
    
	_state = GameStateWaitingForSignIn;
    statuslabel = [CCLabelTTF labelWithString:@"waiting for game to start" fontName:@"Marker Felt" fontSize:24];
    statuslabel.color= ccc3(255, 0, 0);
    statuslabel.position = ccp(winSize.width/2, winSize.height/2);
    // add the label as a child to this Layer
    [self addChild: statuslabel];
    
    self.TouchEnabled = NO;
    //TODO: waiting for game to start
	//[self gameWaitingForServerReady];
    
}
- (void)startServerGameWithSession:(GKSession *)session playerName:(NSString *)name client:(NSArray *)client{
    self.isServer = YES;
    
	_session = session;
	_session.available = NO;
	_session.delegate = self;
	[_session setDataReceiveHandler:self withContext:nil];
    
	_state = GameStateWaitingForSignIn;
    
	//[self gameWaitingForClientsReady:self];
    
    // Create the Player object for the server.
	Player *player = [[Player alloc] init];
	player.name = name;
	player.peerID = _session.peerID;
	player.position = PlayerPositionBottom;
	[_players setObject:player forKey:player.peerID];
    
	// Add a Player object for each client.
	int index = 0;
	for (NSString *peerID in client)
	{
		Player *player = [[Player alloc] init];
		player.peerID = peerID;
		[_players setObject:player forKey:player.peerID];
        
		if (index == 0)
			player.position = ([client count] == 1) ? PlayerPositionTop : PlayerPositionLeft;
		else if (index == 1)
			player.position = PlayerPositionTop;
		else
			player.position = PlayerPositionRight;
        
		index++;
	}
    
    
    
    Packet *packet = [Packet packetWithType:PacketTypeSignInRequest];
	[self sendPacketToAllClients:packet];
}


- (void)quitGameWithReason:(QuitReason)reason
{
    
    _state = GameStateQuitting;
    
	if (reason == QuitReasonUserQuit)
	{
		if (self.isServer)
		{
			Packet *packet = [Packet packetWithType:PacketTypeServerQuit];
			[self sendPacketToAllClients:packet];
		}
		else
		{
            //try to send only if connection with server exists
            if (_serverPeerID != nil){
                Packet *packet = [Packet packetWithType:PacketTypeClientQuit];
                [self sendPacketToServer:packet];
            }
		}
	}
    
	[_session disconnectFromAllPeers];
	_session.delegate = nil;
	_session = nil;
    
	//[self.delegate game:self didQuitWithReason:reason];
    
	if (reason == QuitReasonConnectionDropped)
    {
        [self showDisconnectedAlert];
    }
    
}

#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
	if (buttonIndex != alertView.cancelButtonIndex)
	{
        
		[self quitGameWithReason:QuitReasonUserQuit];
        CCScene *MainMenuScene = [HelloWorldLayer scene];
        
        [[CCDirector sharedDirector] replaceScene:[CCTransitionJumpZoom transitionWithDuration:0.5f scene:MainMenuScene]];
	}
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView==resetGameAlert) {
        if (buttonIndex == 0) {
           
            [[CCDirector sharedDirector] replaceScene:[CCTransitionJumpZoom transitionWithDuration:0.5f scene:[RLGameRun scene]]];
        }
        if (buttonIndex == 1) {
            return;
        }
    }
    if (alertView==disconnectedAlertView) {
        if (buttonIndex == 0) {
            CCScene *MainMenuScene = [HelloWorldLayer scene];
            
            [[CCDirector sharedDirector] replaceScene:[CCTransitionJumpZoom transitionWithDuration:0.5f scene:MainMenuScene]];
        }
        if (alertView==gameOverMoveAlert) {
            if (buttonIndex == 0) {
                [self resetGame];
                
            }
            if (buttonIndex == 1) {
                return;
            }
        }
        
        
        
        if (buttonIndex == 1) {
            return;
        }
    }
}

#pragma mark - GKSessionDelegate

- (void)session:(GKSession *)session peer:(NSString *)peerID didChangeState:(GKPeerConnectionState)state
{
#ifdef DEBUG
	NSLog(@"Game: peer %@ changed state %d", peerID, state);
#endif
    if (state == GKPeerStateDisconnected)
	{
		if (self.isServer)
		{
			[self clientDidDisconnect:peerID];
		}else if ([peerID isEqualToString:_serverPeerID])
		{
			[self quitGameWithReason:QuitReasonConnectionDropped];
		}
	}
}
- (void)clientDidDisconnect:(NSString *)peerID
{
	if (_state != GameStateQuitting)
	{
		Player *player = [self playerWithPeerID:peerID];
		if (player != nil)
		{
			[_players removeObjectForKey:peerID];
			//[self playerDidDisconnect:player];
		}
	}
}

- (void)session:(GKSession *)session didReceiveConnectionRequestFromPeer:(NSString *)peerID
{
#ifdef DEBUG
	NSLog(@"Game: connection request from peer %@", peerID);
#endif
    
	[session denyConnectionFromPeer:peerID];
}

- (void)session:(GKSession *)session connectionWithPeerFailed:(NSString *)peerID withError:(NSError *)error
{
#ifdef DEBUG
	NSLog(@"Game: connection with peer %@ failed %@", peerID, error);
#endif
    
	// Not used.
}

- (void)session:(GKSession *)session didFailWithError:(NSError *)error
{
#ifdef DEBUG
	NSLog(@"Game: session failed %@", error);
#endif
    
	if ([[error domain] isEqualToString:GKSessionErrorDomain])
	{
		if (_state != GameStateQuitting)
		{
			[self quitGameWithReason:QuitReasonConnectionDropped];
		}
	}
}

#pragma mark - GKSession Data Receive Handler

- (void)receiveData:(NSData *)data fromPeer:(NSString *)peerID inSession:(GKSession *)session context:(void *)context
{
#ifdef DEBUG
	NSLog(@"Game: receive data from peer: %@, data: %@, length: %d", peerID, data, [data length]);
#endif
    Packet *packet = [Packet packetWithData:data];
	if (packet == nil)
	{
		NSLog(@"Invalid packet: %@", data);
		return;
	}
    
	Player *player = [self playerWithPeerID:peerID];
	if (player != nil)
	{
		player.receivedResponse = YES;  // this is the new bit
	}
    
	if (self.isServer)
		[self serverReceivedPacket:packet fromPlayer:player];
	else
		[self clientReceivedPacket:packet];
    
}

- (void)serverReceivedPacket:(Packet *)packet fromPlayer:(Player *)player
{
	switch (packet.packetType)
	{
		case PacketTypeSignInResponse:
			if (_state == GameStateWaitingForSignIn)
			{
				player.name = ((PacketSignInResponse *)packet).playerName;
                
				NSLog(@"server received sign in from client '%@'", player.name);
                if ([self receivedResponsesFromAllPlayers])
				{
					_state = GameStateWaitingForReady;
                    Packet *packet = [PacketServerReady packetWithPlayers:_players];
					[self sendPacketToAllClients:packet];
					NSLog(@"all clients have signed in");
				}			}
			break;
        case PacketTypeClientReady:
			if (_state == GameStateWaitingForReady && [self receivedResponsesFromAllPlayers])
			{
				[self beginGame];
			}
			break;
        case PacketTypeClientQuit:
			[self clientDidDisconnect:player.peerID];
			break;
        case PacketTypeMove:
            if (_state == GameStatePlaying){
                [self movePawn:packet];
            }
            //TODO
            break;
            
        default:
			NSLog(@"Server received unexpected packet: %@", packet);
			break;
	}
}

- (BOOL)receivedResponsesFromAllPlayers
{
	for (NSString *peerID in _players)
	{
		Player *player = [self playerWithPeerID:peerID];
		if (!player.receivedResponse)
			return NO;
	}
	return YES;
}

- (Player *)playerWithPeerID:(NSString *)peerID
{
	return [_players objectForKey:peerID];
}

#pragma mark - Networking

- (void)sendPacketToAllClients:(Packet *)packet
{
    
    [_players enumerateKeysAndObjectsUsingBlock:^(id key, Player *obj, BOOL *stop)
     {
         obj.receivedResponse = [_session.peerID isEqualToString:obj.peerID];
     }];
    
	GKSendDataMode dataMode = GKSendDataReliable;
	NSData *data = [packet data];
	NSError *error;
	if (![_session sendDataToAllPeers:data withDataMode:dataMode error:&error])
	{
		NSLog(@"Error sending data to clients: %@", error);
	}
}

- (void)clientReceivedPacket:(Packet *)packet
{
	switch (packet.packetType)
	{
		case PacketTypeSignInRequest:
			if (_state == GameStateWaitingForSignIn)
			{
				_state = GameStateWaitingForReady;
                
				Packet *packet = [PacketSignInResponse packetWithPlayerName:_localPlayerName];
				[self sendPacketToServer:packet];
			}
			break;
        case PacketTypeServerReady:
			if (_state == GameStateWaitingForReady)
			{
				_players = ((PacketServerReady *)packet).players;
                // [self changeRelativePositionsOfPlayers];
                Packet *packet = [Packet packetWithType:PacketTypeClientReady];
				[self sendPacketToServer:packet];
                [self beginGame];
				NSLog(@"the players are: %@", _players);
			}
			break;
        case PacketTypeServerQuit:
			[self quitGameWithReason:QuitReasonServerQuit];
			break;
        case PacketTypeMove:
            if (_state == GameStatePlaying){
                [self movePawn:packet];
            }
            break;
        default:
			NSLog(@"Client received unexpected packet: %@", packet);
			break;
	}
}

-(void)movePawn:(Packet *)packet{
    
    NSString *endTag = ((PacketSendMove *)packet).endTag;
    NSString *pawnTag = ((PacketSendMove *)packet).pawnTag;
    NSString *eliminate = ((PacketSendMove *)packet).eliminate;
    NSString *startTag = ((PacketSendMove *)packet).startTag;
    
    CCLOG(@"got %@ %@ %@ %@",endTag,pawnTag,eliminate,startTag);
    
    if ([eliminate isEqualToString:@"OVER"]) {
        if (self.isServer && [whoWon isEqualToString:@"X"]) {
            return;
        }
        if (self.isServer && [whoLost isEqualToString:@"X"]) {
            [[CCDirector sharedDirector] replaceScene:[CCTransitionJumpZoom transitionWithDuration:0.5f scene:[RLGameRun scene]]];
            
        }
        if (!self.isServer && [whoWon isEqualToString:@"O"]) {
            return;
        }
        if (!self.isServer && [whoLost isEqualToString:@"O"]) {
            [[CCDirector sharedDirector] replaceScene:[CCTransitionJumpZoom transitionWithDuration:0.5f scene:[RLGameRun scene]]];
        }
        

    }
    
    //get the pawn the opponent has moved
    Pawn *mpawn = (Pawn *)[self getChildByTag:[pawnTag intValue]];
    
    
    
    //get square center coordinates from endTag
    NSValue *endPoint = [centers objectForKey:endTag];
    CGPoint point = [endPoint CGPointValue];
    
    //we have moved
    mpawn.isInBase=NO;
    
    //move the pawn there
    [mpawn runAction:[CCMoveTo actionWithDuration:0.25 position:point]];
    //un-occuppy start square
    Square *ss = (Square *)[self getChildByTag:[startTag integerValue]];
    ss.isOccuppied = NO;
    ss.havePawn = -1;
    
    //make the square occupied
    Square *s = (Square *)[self getChildByTag:[endTag integerValue]];
    s.isOccuppied = YES;
    s.havePawn = mpawn.tag;
    
    //CHECK ELIMINATION
    if ([eliminate isEqualToString:@"YES"]) {
        [self vanishAnimation:mpawn];
        [self setTouchEnabled:YES];
        //make the square free
        Square *s = (Square *)[self getChildByTag:[endTag integerValue]];
        s.isOccuppied = NO;
        s.havePawn = -1;
        //return;
    }
    
    //check if pawn blocked other pawns
    //the pawn that may be blocked by a movement, reside in end_tag+1/end_tag-1
    //end_tag+8,end_tag-8
    [self eliminateNeighbors:[endTag integerValue]+1];
    [self eliminateNeighbors:[endTag integerValue]-1];
    [self eliminateNeighbors:[endTag integerValue]+BOARD];
    [self eliminateNeighbors:[endTag integerValue]-BOARD];
    
    //3rd if no base adjacent squares are available
    [self checkBase];
    
    //check game over
    [self checkGameOver:[endTag integerValue]];
    
    //indicate that the other player can play
    if (mpawn.tag<200) { //server moved
        OcanPlay=YES;
    }else if (mpawn.tag>=200){ //client moved
        XcanPlay=YES;
    }
    
    
}


- (void)beginGame
{
	_state = GameStatePlaying;
    self.touchEnabled=YES;
    [statuslabel setString:@""];
	NSLog(@"the game may begin");
}

/*
 - (void)changeRelativePositionsOfPlayers
 {
 NSAssert(!self.isServer, @"Must be client");
 
 Player *myPlayer = [self playerWithPeerID:_session.peerID];
 int diff = myPlayer.position;
 myPlayer.position = PlayerPositionBottom;
 
 [_players enumerateKeysAndObjectsUsingBlock:^(id key, Player *obj, BOOL *stop)
 {
 if (obj != myPlayer)
 {
 obj.position = (obj.position - diff) % 4;
 }
 }];
 }*/

- (void)sendPacketToServer:(Packet *)packet
{
	GKSendDataMode dataMode = GKSendDataReliable;
    
	NSData *data = [packet data];
	NSError *error;
    
    //try to send only if a session exist
    if (_session){
        
        if (![_session sendData:data toPeers:[NSArray arrayWithObject:_serverPeerID] withDataMode:dataMode error:&error])
        {
            NSLog(@"Error sending data to server: %@", error);
        }else{
            NSLog(@"client sends:%@",data);
        }
    }
}

-(void)goMenu{
    if (self.isServer)
	{
		_alertView = [[UIAlertView alloc]
                      initWithTitle:NSLocalizedString(@"End Game?", @"Alert title (user is host)")
                      message:NSLocalizedString(@"This will terminate the game for all other players.", @"Alert message (user is host)")
                      delegate:self
                      cancelButtonTitle:NSLocalizedString(@"No", @"Button: No")
                      otherButtonTitles:NSLocalizedString(@"Yes", @"Button: Yes"),
                      nil];
        
		[_alertView show];
	}
	else
	{
		_alertView = [[UIAlertView alloc]
                      initWithTitle: NSLocalizedString(@"Leave Game?", @"Alert title (user is not host)")
                      message:nil
                      delegate:self
                      cancelButtonTitle:NSLocalizedString(@"No", @"Button: No")
                      otherButtonTitles:NSLocalizedString(@"Yes", @"Button: Yes"),
                      nil];
        
		[_alertView show];
	}
    
    //[self quitGameWithReason:QuitReasonUserQuit];
    //CCScene *MainMenuScene = [HelloWorldLayer scene];
    
    //[[CCDirector sharedDirector] replaceScene:[CCTransitionJumpZoom transitionWithDuration:0.5f scene:MainMenuScene]];
}



- (void)showDisconnectedAlert
{
	disconnectedAlertView = [[UIAlertView alloc]
                             initWithTitle:NSLocalizedString(@"Disconnected", @"Client disconnected alert title")
                             message:NSLocalizedString(@"You were disconnected from the game.", @"Client disconnected alert message")
                             delegate:nil
                             cancelButtonTitle:NSLocalizedString(@"OK", @"Button: OK")
                             otherButtonTitles:nil];
    
	[disconnectedAlertView show];
}

-(void)pauseGame{
    
}
-(void)resetGame{
    if (canReset){
        //alert first
        resetGameAlert = [[UIAlertView alloc]initWithTitle:@"Restart Game" message:@"Restart game?" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:@"Cancel", nil];
        
        [resetGameAlert show];
    }
    
}




-(void)resumeGame{
    
}
-(void)pauseButtonTapped:(id)sender{
    
}


-(void)calculateSquareCenters{
    //these are the position center a pawn can be dropped
    //also accompanied by the square tag starting from 0, so we use a dictionary
    centers = [[NSMutableDictionary alloc]init];
    int tag=0;
    for (int i=0; i<BOARD; i++) {
        for (int j=0; j<BOARD; j++) {
            CGPoint p = CGPointMake(((SQUARE+SQUARE_MARGIN)*i)+WINDOW_MARGIN,((SQUARE+SQUARE_MARGIN)*j)+WINDOW_MARGIN);
            NSValue *pp = [NSValue valueWithCGPoint:p];
            NSString *ptag = [NSString stringWithFormat:@"%i",tag];
            [centers setObject:pp forKey:ptag];
            tag++;
        }
    }
    
    //CCLOG(@"%@",centers);
    //how to get the points
    //NSValue *getPoint = [centers objectAtIndex:0];
    //CGPoint thePoint = [getPoint CGPointValue];
}

-(void)checkEndPosition:(NSSet *)touches{
    //get stopped location
    UITouch *touch = [touches anyObject];
    CGPoint location = [touch locationInView:[touch view]];
    location = [[CCDirector sharedDirector]convertToGL:location];
    //NSInteger end_tag;
    //get all sprites
    CCArray *allSprites = [self children];
    
    //get adjacent square tags
    adjSquareTags = [[NSMutableArray alloc]initWithArray:[Board calcAdjSquares]];
    //CCLOG(@"adj squares %@",adjSquareTags);
    
    /*CHECK 1*/
    //Check that we land only on a square
    //Also this covers that we cannot land out of the board (tag will be -1 if we do)
    for (Square *s in allSprites){
        //location helps us to identify the square
        if (CGRectContainsPoint([s boundingBox], location)) {
            //get square that we have stopped
            if ([s isKindOfClass:[Square class]]) {
                
                
                end_tag=s.tag;
                //CCLOG(@"end tag=%i",s.tag);
                if ([s tag] != -1){
                    /*CHECK 2*/
                    //If the pawn is in the base, then it can move only to any
                    //adjacent to the base square. Not the corner one though!
                    //Check also that the move in no more than one square.
                    //Go back to start position
                    //adjSquareTags contains the tags of the adjacent to a base squares
                    //first #BASE^2 +1 entries are for X and last #BASE^2 +1 entries are for O
                    if ([currentPawn isInBase] && [[currentPawn type]isEqualToString:@"X"]) {
                        
                        for (int i=0; i<(BASE*BASE)+1; i++) {
                            
                            NSInteger tmp = [[adjSquareTags objectAtIndex:i]intValue];
                            //exclude the corner one
                            //it has tag BASE+BOARD*BASE
                            if (end_tag==BASE+BOARD*BASE) {
                                continue;
                            }
                            if (end_tag==tmp) {
                                CHECK_FIRST=YES;
                            }
                            
                        }
                        
                    }else if ([currentPawn isInBase] && [[currentPawn type]isEqualToString:@"O"]){
                        for (int i=(BASE*BASE)+1; i<2*(BASE*BASE)+1; i++) {
                            //exclude the corner one
                            //it has tag ((BOARD*BOARD)-BASE-1)-BOARD*BASE
                            if (end_tag==((BOARD*BOARD)-BASE-1)-BOARD*BASE) {
                                continue;
                            }
                            int tmp = [[adjSquareTags objectAtIndex:i]intValue];
                            if (end_tag==tmp) {
                                CHECK_FIRST=YES;
                            }
                        }
                    }
                    
                    if (currentPawn.isInBase && !CHECK_FIRST) {
                        
                        currentPawn.position=ccp(touchstartx,touchstarty);
                        UIAlertView *firstMoveAlert = [[UIAlertView alloc]initWithTitle:@"First Move" message:@"You can move only to the base's adjacent squares" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                        [firstMoveAlert show];
                        [firstMoveAlert release];
                        weMoved=NO;
                        break;
                    }else{
                        CHECK_FIRST=NO;
                    }
                    /*CHECK 3*/
                    //Check if the square is not occuppied
                    if (![s isOccuppied]){
                        /*CHECK 4*/
                        //check if is in base then move only to adjacent squares
                        if (![currentPawn isInBase]){
                            
                            if([[currentPawn type]isEqualToString:@"X"]) {
                                //(x,y)-->(x,z)
                                //RULE vertical: max(x-BASE,y-BASE) <= max(x-BASE,z-BASE)
                                //(x,y)-->(z,y)
                                //RULE horizontal:max (x-BASE, y-BASE) <= max (z-BASE, y-BASE)
                                //CCLOG(@"max start %i",MAX(startposx-BASE, startposy-BASE));
                                //CCLOG(@"max end %i",MAX(startposx-BASE, s.ycoord-BASE));
                                /*CHECK 5*/
                                //check that we moved only one square then proceed to the next checks
                                //CCLOG(@"TEST %i %i",abs(s.xcoord - startposx),abs(s.ycoord - startposy));
                                //CCLOG(@"TEST2 %i %i",s.xcoord - startposx,s.ycoord - startposy);
                                /*CHECK 6*/
                                //we can't move diagonally. If so then both coordinates change by 1
                                /*CHECK 7*/
                                //check that the distance from the base is not reducing
                                if (((abs(s.xcoord - startposx) == 1) || abs(s.ycoord - startposy) == 1)
                                    && ((s.xcoord - startposx) == 0 || (s.ycoord - startposy) == 0)
                                    && ((MAX(startposx-BASE, startposy-BASE)<=MAX(startposx-BASE, s.ycoord-BASE)) && (MAX(startposx-BASE, startposy-BASE) <= MAX(s.xcoord-BASE, startposy-BASE)))) {
                                    currentPawn.position=s.position;
                                    [currentPawn setIsInBase:NO];
                                    //mark square as occuppied
                                    Square *endsquare = (Square *)[self getChildByTag:end_tag];
                                    endsquare.isOccuppied = YES;
                                    endsquare.havePawn=currentPawn.tag;
                                    //mark start square un-occuppied
                                    //NSLog(@"starttag=%i",starttag);
                                    Square *startsquare = (Square *)[self getChildByTag:starttag];
                                    startsquare.isOccuppied = NO;
                                    startsquare.havePawn=-1;
                                    weMoved=YES;
                                    //CCLOG(@"xy=%i%i",s.xcoord,s.ycoord);
                                    //IMPORTANT!we should break the loop if we land ok
                                    //or we may get a tag=-1
                                    break;
                                }else{
                                    currentPawn.position=ccp(touchstartx,touchstarty);
                                    UIAlertView *illegalMoveAlert = [[UIAlertView alloc]initWithTitle:@"Illegal Move" message:@"You can't move more than one square, diagonally or reduce distance from your base" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                                    [illegalMoveAlert show];
                                    [illegalMoveAlert release];
                                    weMoved=NO;
                                    return; //important!
                                    break;
                                }
                            }else if ([[currentPawn type]isEqualToString:@"O"]){
                                //(x,y)-->(x,z)
                                //RULE vertical: max(BOARD-BASE-x,BOARD-BASE-y) <= max(BOARD-BASE-x,BOARD-BASE-z)
                                //(x,y)-->(z,y)
                                //RULE horizontal:max(BOARD-BASE-x,BOARD-BASE-y) ≤ max (BOARD-BASE-z,BOARD-BASE-y)
                                //CCLOG(@"max start %i",MAX(BOARD-BASE-startposx, BOARD-BASE-startposy));
                                //CCLOG(@"max end %i",MAX(BOARD-BASE-startposx, BOARD-BASE-s.ycoord));
                                /*CHECK 5*/
                                //check that we moved only one square then proceed to the next checks
                                /*CHECK 6*/
                                //we can't move diagonally. If so then both coordinates change by 1
                                /*CHECK 7*/
                                //check that the distance from the base is not reducing
                                if (((abs(startposx - s.xcoord) == 1) || abs(startposy - s.ycoord) == 1)
                                    && ((startposx - s.xcoord) == 0 || (startposy - s.ycoord) == 0)
                                    && ((MAX(BOARD-BASE-startposx, BOARD-BASE-startposy)<=MAX(BOARD-BASE-startposx, BOARD-BASE-s.ycoord)) && (MAX(BOARD-BASE-startposx, BOARD-BASE-startposy) <= MAX(BOARD-BASE-s.xcoord, BOARD-BASE-startposy)))) {
                                    currentPawn.position=s.position;
                                    [currentPawn setIsInBase:NO];
                                    //mark square as occuppied
                                    Square *endsquare = (Square *)[self getChildByTag:end_tag];
                                    endsquare.isOccuppied = YES;
                                    endsquare.havePawn=currentPawn.tag;
                                    //mark start square un-occuppied
                                    //NSLog(@"starttag=%i",starttag);
                                    Square *startsquare = (Square *)[self getChildByTag:starttag];
                                    startsquare.isOccuppied = NO;
                                    startsquare.havePawn=-1;
                                    weMoved=YES;
                                    //CCLOG(@"xy=%i%i",s.xcoord,s.ycoord);
                                    //IMPORTANT!we should break the loop if we land ok
                                    //or we may get a tag=-1
                                    break;
                                }else{
                                    currentPawn.position=ccp(touchstartx,touchstarty);
                                    UIAlertView *illegalMoveAlert = [[UIAlertView alloc]initWithTitle:@"Illegal Move" message:@"You can't move more than one square, diagonally or reduce distance from your base" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                                    [illegalMoveAlert show];
                                    [illegalMoveAlert release];
                                    weMoved=NO;
                                    return; //important!
                                    break;
                                }
                            }
                        }else{   //first move outside of the base
                            currentPawn.position=s.position;
                            [currentPawn setIsInBase:NO];
                            //mark square as occupied
                            
                            s.isOccuppied = YES;
                            s.havePawn=currentPawn.tag;
                            
                           // CCLOG(@"xy=%i%i",s.xcoord,s.ycoord);
                            weMoved=YES;
                            
                            
                            
                            //IMPORTANT!we should break the loop if we land ok
                            //or we may get a tag=-1
                            break;
                            
                        }
                    }else{
                        currentPawn.position=ccp(touchstartx,touchstarty);
                        weMoved=NO;
                        break;
                    }
                    
                }else{  //tag=-1
                    //we must have dropped it somewhere in the middle!
                    //go back to start position
                    currentPawn.position=ccp(touchstartx,touchstarty);
                    weMoved=NO;
                    //break;
                }
                
            }else{
                //we must have dropped it somewhere in the middle!
                //go back to start position
                //CCLOG(@"class=%@",s.class);
                currentPawn.position=ccp(touchstartx,touchstarty);
                weMoved=NO;
                //break;
            }
            
        }    }
    //check pawn elimination
    //1st if they can't move
    if (end_tag && weMoved && [self checkElimination:end_tag]) {
        //reduce pawn left
        [[currentPawn type]isEqualToString:@"X"]? --remainingX : --remainingO ;
        //show it
        [[currentPawn type]isEqualToString:@"X"]? [Xlabelvalue setString:[NSString stringWithFormat:@"%i",remainingX]] : [Olabelvalue setString:[NSString stringWithFormat:@"%i",remainingO]];
        //vanish pawn
        //hide with some animation
        //CCLOG(@"current pawn tag=%c",currentPawn.tag);
        
        [self vanishAnimation:currentPawn];
        [self setTouchEnabled:YES];
        //make square free again
        Square *s = (Square *)[self getChildByTag:end_tag];
        s.isOccuppied=NO;
        s.havePawn=-1;
        
        if (P2P) {
            
            //send packet
            Packet *packet = [PacketSendMove packetWithEndTagAndPawn:[NSString stringWithFormat:@"%i",end_tag] pawn:[NSString stringWithFormat:@"%i",currentPawn.tag] eliminate:@"YES" starttag:[NSString stringWithFormat:@"%i",starttag]];
            if (self.isServer) {
                [self sendPacketToAllClients:packet];
            }else{
                [self sendPacketToServer:packet];
            }
        }
    }
    
    //2nd check if pawn blocked other pawns
    //the pawn that may be blocked by a movement, reside in end_tag+1/end_tag-1
    //end_tag+8,end_tag-8
    [self eliminateNeighbors:end_tag+1];
    [self eliminateNeighbors:end_tag-1];
    [self eliminateNeighbors:end_tag+BOARD];
    [self eliminateNeighbors:end_tag-BOARD];
    
    //3rd if no base adjacent squares are available
    [self checkBase];
    
    //check game over
    [self checkGameOver:end_tag];
    
}

-(void)checkBase{
    //get all sprites
    CCArray *allSprites = [self children];
    //adjSquareTags contains the tags of the adjacent to a base squares
    //first #BASE^2 +1 entries are for X and last #BASE^2 +1 entries are for O
    int allXbaseoccuppied = 0;
    int allObaseoccuppied = 0;
    
    for (int i=0; i<(BASE*BASE)+1; i++) {
        
        NSInteger tmp = [[adjSquareTags objectAtIndex:i]intValue];
        CCLOG(@"tags %i",tmp);
        Square *stmp = (Square *)[self getChildByTag:tmp];
        stmp.isOccuppied ?allXbaseoccuppied++:allXbaseoccuppied;
    }
    for (int i=(BASE*BASE)+1; i<=2*(BASE*BASE)+1; i++) {
        
        int tmp = [[adjSquareTags objectAtIndex:i]intValue];
        Square *stmp = (Square *)[self getChildByTag:tmp];
        stmp.isOccuppied ?allObaseoccuppied++:allObaseoccuppied;
    }
    
    if (!XbaseEmpty) { //so we don't have to execute this code if the base is empty
        
        
        if (allXbaseoccuppied == (BASE*BASE)+1) {
            //iterate all Pawns that are inside the base and vanish them if they are visible
            for (Pawn *p in allSprites) {
                if (p.tag > BOARD*BOARD) {
                    Pawn *ptmp = (Pawn *)[self getChildByTag:p.tag];
                    if ([[ptmp type]isEqualToString:@"X"] &&  ptmp.isInBase && ptmp.visible) {
                        remainingX--;
                        if(!ZOMBIE){
                        [Xlabelvalue setString:[NSString stringWithFormat:@"%i",remainingX]];
                        //hide with some animation
                        [self vanishAnimation:ptmp];
                            [self setTouchEnabled:YES];
                        }
                    }
                }
            }
            
        }
    }
    if (allXbaseoccuppied == (BASE*BASE)+1) {
        //if we reached this number then the base must be empty
        XbaseEmpty=YES;
    }
    
    if (!ObaseEmpty) {
        if (allObaseoccuppied == (BASE*BASE)+1) {
            //iterate all Pawns that are inside the base and vanish them if they are visible
            for (Pawn *p in allSprites) {
                if (p.tag > BOARD*BOARD) {
                    Pawn *ptmp = (Pawn *)[self getChildByTag:p.tag];
                    if ([[ptmp type]isEqualToString:@"O"] && ptmp.isInBase && ptmp.visible) {
                        remainingO--;
                        if(!ZOMBIE){
                        [Olabelvalue setString:[NSString stringWithFormat:@"%i",remainingO]];
                        //hide with some animation
                        [self vanishAnimation:ptmp];
                            [self setTouchEnabled:YES];
                        }
                        
                    }
                }
            }
            
        }
    }
    if (allObaseoccuppied == (BASE*BASE)+1) {
        //if we reached this number then the base must be empty
        ObaseEmpty=YES;
    }
}

-(void)eliminateNeighbors:(int)endtag{
    if (endtag<0) {
        return;
    }
    if ([self getChildByTag:endtag]) { //if we have such a square
        Square *s = (Square *)[self getChildByTag:endtag];
        if (s.isOccuppied) {
            if([self checkElimination:endtag]){
                if (s.havePawn <200) {
                    --remainingX;
                    [Xlabelvalue setString:[NSString stringWithFormat:@"%i",remainingX]];
                }else if (s.havePawn>=200){
                    --remainingO;
                    [Olabelvalue setString:[NSString stringWithFormat:@"%i",remainingO]];
                }
                if(!ZOMBIE){
                [self vanishAnimation:(Pawn *)[self getChildByTag:s.havePawn]];
                [self setTouchEnabled:YES];
                //make square free again
                Square *s = (Square *)[self getChildByTag:endtag];
                s.isOccuppied=NO;
                s.havePawn =-1;
                }
            }
            
            
        }
    }
}

-(void)vanishAnimation:(Pawn *)sprite{
    [self setTouchEnabled:NO];
    CCScaleBy *sc1 = [CCScaleBy actionWithDuration:0.25 scale:0.9];
    CCScaleBy *sc2 = [CCScaleBy actionWithDuration:0.25 scale:0.8];
    CCScaleBy *sc3 = [CCScaleBy actionWithDuration:0.25 scale:0.7];
    CCScaleBy *sc4 = [CCScaleBy actionWithDuration:0.25 scale:0.6];
    CCScaleBy *sc5 = [CCScaleBy actionWithDuration:0.25 scale:0.5];
    CCScaleBy *sc6 = [CCScaleBy actionWithDuration:0.25 scale:0.4];
    CCScaleBy *sc7 = [CCScaleBy actionWithDuration:0.25 scale:0.3];
    CCScaleBy *sc8 = [CCScaleBy actionWithDuration:0.25 scale:0.2];
    CCScaleBy *sc9 = [CCScaleBy actionWithDuration:0.25 scale:0.1];
    CCHide *sh = [CCHide action];
    
    [sprite runAction:[CCSequence actions:sc1,sc2,sc3,sc4,sc5,sc6,sc7,sc8,sc9,sh,nil]];
}

-(void)gameOverAlert:(NSString *)won lost:(NSString *)lost{
    gameOverMoveAlert = [[UIAlertView alloc]initWithTitle:[NSString stringWithFormat:@"Congratulations %@",won] message:[NSString stringWithFormat:@"Sorry %@ You Lose!!! Guard your base better next time!",lost] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [gameOverMoveAlert show];
    //GAME RESET
    //[self removeAllChildrenWithCleanup:YES];
    [[CCDirector sharedDirector] replaceScene:[CCTransitionJumpZoom transitionWithDuration:0.5f scene:[RLGameRun scene]]];
}

-(BOOL)checkGameOver:(NSInteger)end_tag{
    //whoWon = nil;
    //whoLost = nil;
    /*1*/
    //no more pawns left!
    if (!remainingO || !remainingX) {
        
        
        if (remainingX == 0) {
            whoWon=@"O";
            whoLost=@"X";
            
        }else if (remainingO == 0){
            whoWon=@"X";
            whoLost=@"O";
        }
        if(!ZOMBIE){
        [self gameOverAlert:whoWon lost:whoLost];
            //send packet
            Packet *packet = [PacketSendMove packetWithEndTagAndPawn:[NSString stringWithFormat:@"%i",end_tag] pawn:[NSString stringWithFormat:@"%i",currentPawn.tag] eliminate:@"OVER" starttag:[NSString stringWithFormat:@"%i",starttag]];
            if (self.isServer) {
                [self sendPacketToAllClients:packet];
            }else{
                [self sendPacketToServer:packet];
            }

        }
        return YES;
    }
    
    /*2*/
    //stepped the other base!
    //check if we are in the other base. (and of course we are not in ours!)
    
    for (int i=BASE*BASE; i<2*BASE*BASE; i++) {
        NSInteger tmp = [[baseSquareTags objectAtIndex:i]integerValue];
        if (!currentPawn.isInBase && end_tag==tmp) {
            whoWon=@"X";
            whoLost=@"O";
            if(!ZOMBIE){
                [self gameOverAlert:whoWon lost:whoLost];
                //send packet
                Packet *packet = [PacketSendMove packetWithEndTagAndPawn:[NSString stringWithFormat:@"%i",end_tag] pawn:[NSString stringWithFormat:@"%i",currentPawn.tag] eliminate:@"OVER" starttag:[NSString stringWithFormat:@"%i",starttag]];
                if (self.isServer) {
                    [self sendPacketToAllClients:packet];
                }else{
                    [self sendPacketToServer:packet];
                }

            }            return YES;
            break;
        }
    }
    
    for (int i=0; i<BASE*BASE; i++) {
        NSInteger tmp = [[baseSquareTags objectAtIndex:i]integerValue];
        if (!currentPawn.isInBase && end_tag==tmp) {
            whoWon=@"O";
            whoLost=@"X";
            if(!ZOMBIE){
                [self gameOverAlert:whoWon lost:whoLost];
                //send packet
                Packet *packet = [PacketSendMove packetWithEndTagAndPawn:[NSString stringWithFormat:@"%i",end_tag] pawn:[NSString stringWithFormat:@"%i",currentPawn.tag] eliminate:@"OVER" starttag:[NSString stringWithFormat:@"%i",starttag]];
                if (self.isServer) {
                    [self sendPacketToAllClients:packet];
                }else{
                    [self sendPacketToServer:packet];
                }

            }
            return YES;
            break;
        }
    }
    
    
    
    return NO;
}

-(BOOL)checkElimination:(NSInteger)end_tag{
    if (end_tag==-1) {
        return NO;
    }
    //get all sprites
    CCArray *allSprites = [self children];
    //int occuppied = 0;
    BOOL CAN_MOVE = YES;
    NSMutableArray *can_move;

    BOOL side = NO;
    for (Square *s in allSprites){
        //get square that we have stopped.
        if ([s tag] != -1 && [s tag] == end_tag) {
            //check left,right and top/bottom square if they are occuppied
            //or if we reduced distance from base
            //count out the bases also
            can_move = [[NSMutableArray alloc]init];
            if (end_tag-BOARD>0 && [self getChildByTag:end_tag-BOARD]) {
                Square *leftsquare = (Square *)[self getChildByTag:end_tag-BOARD];
                //NSLog(@"left=%i",leftsquare.tag);
                if (s.havePawn>=100 && s.havePawn<200) {
                    if (((MAX(s.xcoord-BASE, s.ycoord-BASE) > MAX(leftsquare.xcoord-BASE, s.ycoord-BASE))) || leftsquare.isOccuppied) {
                        //occuppied++;
                        CAN_MOVE=NO;
                        [can_move addObject:[NSNumber numberWithBool:CAN_MOVE]];
                    }
                    else{
                        CAN_MOVE=YES;
                        [can_move addObject:[NSNumber numberWithBool:CAN_MOVE]];
                    }
                }else if (s.havePawn>=200){
                    if (((MAX(BOARD-BASE-s.xcoord, BOARD-BASE-s.ycoord) > MAX(BOARD-BASE-leftsquare.xcoord, BOARD-BASE-s.ycoord))) || leftsquare.isOccuppied) {
                        //occuppied++;
                        CAN_MOVE=NO;
                        [can_move addObject:[NSNumber numberWithBool:CAN_MOVE]];
                    }
                    else{
                        CAN_MOVE=YES;
                        [can_move addObject:[NSNumber numberWithBool:CAN_MOVE]];
                    }
                }
                
                //leftsquare.isOccuppied ? occuppied++ : occuppied;
                
            }else{
                side=YES;
            }
            
            if (end_tag+BOARD>0 && [self getChildByTag:end_tag+BOARD]) {
                Square *rightsquare = (Square *)[self getChildByTag:end_tag+BOARD];
                //NSLog(@"right=%i",rightsquare.tag);
                if (s.havePawn>=100 && s.havePawn<200) {
                    if (((MAX(s.xcoord-BASE, s.ycoord-BASE) > MAX(rightsquare.xcoord-BASE, s.ycoord-BASE))) || rightsquare.isOccuppied) {
                        //occuppied++;
                        CAN_MOVE=NO;
                        [can_move addObject:[NSNumber numberWithBool:CAN_MOVE]];
                    }
                    else{
                        CAN_MOVE=YES;
                        [can_move addObject:[NSNumber numberWithBool:CAN_MOVE]];
                    }
                }else if (s.havePawn>=200){
                    if (((MAX(BOARD-BASE-s.xcoord, BOARD-BASE-s.ycoord) > MAX(BOARD-BASE-rightsquare.xcoord, BOARD-BASE-s.ycoord))) || rightsquare.isOccuppied) {
                        //occuppied++;
                        CAN_MOVE=NO;
                        [can_move addObject:[NSNumber numberWithBool:CAN_MOVE]];                    }
                    else{
                        CAN_MOVE=YES;
                        [can_move addObject:[NSNumber numberWithBool:CAN_MOVE]];
                    }
                }
                //  rightsquare.isOccuppied ? occuppied++ : occuppied;
            }else{
                side=YES;
            }
            
            
            
            if (end_tag+1>0 && [self getChildByTag:end_tag+1]) {
                Square *topsquare = (Square *)[self getChildByTag:end_tag+1];
                //NSLog(@"top=%i",topsquare.tag);
                //prevent move from bottom to top
                if ((topsquare.ycoord - s.ycoord) != 7) {
                    
                    if (s.havePawn>=100 && s.havePawn<200) {
                        if (((MAX(s.xcoord-BASE, s.ycoord-BASE) > MAX(s.xcoord-BASE, topsquare.ycoord-BASE))) || topsquare.isOccuppied || topsquare.ycoord-s.ycoord==1-BOARD) {
                            //occuppied++;
                            CAN_MOVE=NO;
                            [can_move addObject:[NSNumber numberWithBool:CAN_MOVE]];
                        }
                        else{
                            CAN_MOVE=YES;
                            [can_move addObject:[NSNumber numberWithBool:CAN_MOVE]];
                        }
                    }
                    else if (s.havePawn>=200){
                        if (((MAX(BOARD-BASE-s.xcoord, BOARD-BASE-s.ycoord) > MAX(BOARD-BASE-s.xcoord, BOARD-BASE-topsquare.ycoord))) || topsquare.isOccuppied || topsquare.ycoord-s.ycoord==1-BOARD) {
                            //occuppied++;
                            CAN_MOVE=NO;
                            [can_move addObject:[NSNumber numberWithBool:CAN_MOVE]];
                            
                        }
                        else{
                            CAN_MOVE=YES;
                            [can_move addObject:[NSNumber numberWithBool:CAN_MOVE]];
                            
                        }
                    }
                    
                    // topsquare.isOccuppied ? occuppied++ : occuppied;
                }
            }
            
            if (end_tag-1>0 && [self getChildByTag:end_tag-1]) {
                Square *bottomsquare = (Square *)[self getChildByTag:end_tag-1];
               // NSLog(@"bottom=%i",bottomsquare.tag);
                //prevent move from bottom to top
                if ((bottomsquare.ycoord - s.ycoord) != 7) {
                    
                    if (s.havePawn>=100 && s.havePawn<200) {
                        if (((MAX(s.xcoord-BASE, s.ycoord-BASE) > MAX(s.xcoord-BASE, bottomsquare.ycoord-BASE))) || bottomsquare.isOccuppied || bottomsquare.ycoord-s.ycoord==BOARD-1) {
                            //occuppied++;
                            CAN_MOVE=NO;
                            [can_move addObject:[NSNumber numberWithBool:CAN_MOVE]];
                            
                        }
                        else{
                            CAN_MOVE=YES;
                            [can_move addObject:[NSNumber numberWithBool:CAN_MOVE]];
                        }
                    }else if (s.havePawn>=200){
                        if (((MAX(BOARD-BASE-s.xcoord, BOARD-BASE-s.ycoord) > MAX(BOARD-BASE-s.xcoord, BOARD-BASE-bottomsquare.ycoord))) || bottomsquare.isOccuppied || bottomsquare.ycoord-s.ycoord==BOARD-1) {
                            //occuppied++;
                            CAN_MOVE=NO;
                            [can_move addObject:[NSNumber numberWithBool:CAN_MOVE]];
                        }
                        else{
                            CAN_MOVE=YES;
                            [can_move addObject:[NSNumber numberWithBool:CAN_MOVE]];
                        }
                    }
                    //bottomsquare.isOccuppied ? occuppied++ : occuppied;
                }
                break;
            }
        }
    }
    //NSLog(@"occuppied=%i",occuppied);
    
    //when AI, we have to count also the start square
    //which will be occuppied, so 2:3 will become 3:4
    /*if (!XcanPlay) {
     return occuppied==(side?3:4) ? YES :NO;
     }else{
     
     return occuppied==(side?2:3) ? YES :NO;
     }*/
    if ([can_move containsObject:[NSNumber numberWithBool:YES]]) {
        return NO;
    }else{
        return YES;
    }
    
}

- (void)dragPawn:(CGPoint)translation {
    //new location must be a square
    
    CGPoint newPos = ccpAdd(currentPawn.position, translation);
    //CCLOG(@"newPos=%f %f",newPos.x,newPos.y);
    
    
    currentPawn.position = newPos;
    
    
}

-(void)ccTouchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    //CCLOG(@"touch ended");
    
    //to avoid calling checkendposition when in server_client and not moved
    if (P2P) {
        
        if (!server_client_moved) {
            server_client_moved=YES;
            return;
        }
    }
    
    @try {//safe so as not to crash
        
        //check if we can play
        if ([[currentPawn type]isEqualToString:@"X"] && XcanPlay) {
            [self checkEndPosition:touches];
            if (weMoved) {
                //send packet
                if (P2P) {
                    
                    Packet *packet = [PacketSendMove packetWithEndTagAndPawn:[NSString stringWithFormat:@"%i",end_tag] pawn:[NSString stringWithFormat:@"%i",currentPawn.tag] eliminate:@"NO" starttag:[NSString stringWithFormat:@"%i",starttag]];
                    if (self.isServer) {
                        [self sendPacketToAllClients:packet];
                    }else{
                        [self sendPacketToServer:packet];
                    }
                }
                XcanPlay=NO;
            }else{
                
                OcanPlay=NO;
                
            }
            
        }else if ([[currentPawn type]isEqualToString:@"O"] && OcanPlay) {
            [self checkEndPosition:touches];
            if(weMoved){
                //send packet
                if (P2P) {
                    
                    Packet *packet = [PacketSendMove packetWithEndTagAndPawn:[NSString stringWithFormat:@"%i",end_tag] pawn:[NSString stringWithFormat:@"%i",currentPawn.tag] eliminate:@"NO" starttag:[NSString stringWithFormat:@"%i",starttag]];
                    if (self.isServer) {
                        [self sendPacketToAllClients:packet];
                    }else{
                        [self sendPacketToServer:packet];
                    }
                }
                
                OcanPlay=NO;
            }else{
                XcanPlay=NO;
                
                
            }
        }
        
        //[currentPawn stopAllActions];
        //[self checkEndPosition:touches];
        
        //reset position
        [currentPawn runAction:[CCRotateTo actionWithDuration:0.1 angle:0]];
        
        //computer can play
        if (!P2P) {
            [self computerCanPlay];
        }
    }
    @catch (NSException *e) {
        NSLog(@"invalid move %@",e);
    }
    
}

-(void)computerCanPlay{
    
    //Square *testsquare = (Square *)[self getChildByTag:end_tag];
    //NSLog(@"TEST=%hhd",testsquare.isOccuppied);
    
    if (XcanPlay) {
        return;
    }
    
    
    //init possible moves dictionary
    //we store all the possible moves for a pawn in an array
    //we store all the pawns and their moves in a dictionary
    possibleValidMovesDict = [[NSMutableDictionary alloc]init];
    
    
    //get all "O" pawns
    CCArray *allSprites = [self children];
    for (CCSprite *p in allSprites){
        if (p.visible && p.tag >= 200) {
            //NSLog(@"PAWNS- %i ",p.tag);
            //init possible moves array for a pawn
            possibleValidMoves = [[NSMutableArray alloc]init];
            Pawn *pawn = (Pawn *)[self getChildByTag:[p tag]];
            //check if in base
            if (pawn.isInBase) {
                //check the adjacent squares if are empty
                //we already have the array adjSquareTags that hold the tags of the adjacent squares
                //for "O" these tags start frm index BASE*BASE +1
                for (int i=(BASE*BASE)+1; i<2*(BASE*BASE)+1; i++) {
                    int tag = [[adjSquareTags objectAtIndex:i]intValue];
                    //exclude the corner one
                    if (tag==((BOARD*BOARD)-BASE-1)-BOARD*BASE) {
                        continue;
                    }
                    Square *square = (Square *)[self getChildByTag:tag];
                    //if its not occupied, add this tag to the possible moves array
                    if (!square.isOccuppied) {
                        [possibleValidMoves addObject:[NSNumber numberWithInt:tag]];
                    }else{
                        //NSLog(@"square %i is occuppied",tag);
                    }
                }
            }else{  //check pawns outside of the base
                //get the current square tag
                //the pawn lies in the middle of the square
                //they have the same anchor point
                //we can get the square tag and from there the coordinates
                CGPoint pt = CGPointMake(p.position.x,p.position.y);
                NSValue *pp = [NSValue valueWithCGPoint:pt];
                //get the key of the dictionary which corresponds to the tag
                NSArray *temp = [centers allKeysForObject:pp];
                NSString *key = [temp objectAtIndex:0];
                //CCLOG(@"square start tag=%i",[key intValue]);
                Square *s = (Square *)[self getChildByTag:([key intValue])];//start square
                
                //check if front, back, left and right squares are occupied and of course if such squares exist
                //also check if we reduced distance from base horizontally only because we already
                //have excluded going back
                //(x,y)-->(z,y)
                //RULE horizontal:max(BOARD-BASE-x,BOARD-BASE-y) ≤ max (BOARD-BASE-z,BOARD-BASE-y)
                //count out own base squares
                if(([key intValue]-1)>0){
                Square *sf = (Square *)[self getChildByTag:([key intValue]-1)];//front
                //CCLOG(@"front is:%i",[key intValue]-1);
                if (sf && !sf.isOccuppied && ![obasesquares containsObject:[NSNumber numberWithInt:[key intValue]-1]]) {
                    //prevent that the pawn won't jump from bottom to top
                    //because tags are numbered one after the other.
                    //if so, then the y coordinate change by BOARD-1
                    if((sf.ycoord - s.ycoord) != BOARD-1){
                        [possibleValidMoves addObject:[NSNumber numberWithInt:([key intValue]-1)]];
                    }
                }
            }
            if(([key intValue]+1)>0){
                Square *sb = (Square *)[self getChildByTag:([key intValue]+1)];//back
                //CCLOG(@"back is:%i",[key intValue]+1);
                if (sb && !sb.isOccuppied && ![obasesquares containsObject:[NSNumber numberWithInt:[key intValue]+1]]) {
                    //prevent that the pawn won't jump from bottom to top
                    //because tags are numbered one after the other.
                    //if so, then the y coordinate change by 1-BOARD
                    //prevent also not to reduce distance from base
                    if((sb.ycoord - s.ycoord) != 1-BOARD){
                        if((MAX(BOARD-BASE-s.xcoord, BOARD-BASE-s.ycoord)<=MAX(BOARD-BASE-s.xcoord, BOARD-BASE-sb.ycoord)) && MAX(BOARD-BASE-s.xcoord, BOARD-BASE-s.ycoord) <= MAX(BOARD-BASE-sb.xcoord, BOARD-BASE-s.ycoord)){
                        [possibleValidMoves addObject:[NSNumber numberWithInt:([key intValue]+1)]];
                        }
                        
                    }
                }
            }
                
                if(([key intValue]-BOARD)>0){
                Square *sl = (Square *)[self getChildByTag:([key intValue]-BOARD)];//left as we see it
                //NSLog(@"sx/sy--ex/ey=%i/%i--%i/%i",s.xcoord,s.ycoord,sl.xcoord,sl.ycoord);
                if (sl && !sl.isOccuppied && ![obasesquares containsObject:[NSNumber numberWithInt:[key intValue]-BOARD]]) {
                    if((MAX(BOARD-BASE-s.xcoord, BOARD-BASE-s.ycoord)<=MAX(BOARD-BASE-s.xcoord, BOARD-BASE-sl.ycoord)) && MAX(BOARD-BASE-s.xcoord, BOARD-BASE-s.ycoord) <= MAX(BOARD-BASE-sl.xcoord, BOARD-BASE-s.ycoord)){
                        [possibleValidMoves addObject:[NSNumber numberWithInt:([key intValue]-BOARD)]];
                    }
                }
                }
                
                if(([key intValue]+BOARD)>0){
                Square *sr = (Square *)[self getChildByTag:([key intValue]+BOARD)];//right as we see it
                if (sr && !sr.isOccuppied && ![obasesquares containsObject:[NSNumber numberWithInt:[key intValue]+BOARD]]) {
                    if((MAX(BOARD-BASE-s.xcoord, BOARD-BASE-s.ycoord)<=MAX(BOARD-BASE-s.xcoord, BOARD-BASE-sr.ycoord)) && MAX(BOARD-BASE-s.xcoord, BOARD-BASE-s.ycoord) <= MAX(BOARD-BASE-sr.xcoord, BOARD-BASE-s.ycoord)){
                        [possibleValidMoves addObject:[NSNumber numberWithInt:([key intValue]+BOARD)]];
                    }
                }
                
            }
            }
            //store the moves for the pawn in a dictionary only if moves exist
            if ([possibleValidMoves count]) {
                [possibleValidMovesDict setObject:possibleValidMoves forKey:[NSString stringWithFormat:@"%i",p.tag]];
            }
        }
    }
    //NSLog(@"possible moves %@",possibleValidMovesDict);
    
    //add in a temp array, the "O" pawn tags
    NSMutableArray *tmp  = [[NSMutableArray alloc]init];
    for (int i=200; i<200+PAWNS_NUMBER; i++) {
        //check if the pawn has not been eliminated
        Pawn *mpawn = (Pawn *)[self getChildByTag:i];
        if (!mpawn.visible) {
            continue;
        }else{
            [tmp addObject:[NSNumber numberWithInt:i]];
        }
    }
    
    //important to save weights first
    [net storeWeights:@"v_weights" ww:@"w_weights"];
    
    //get the moves for each pawn
    //store the pawn, the move and the response in an array, so to get back the move and pawn from the response
    NSMutableArray *what_to_play = [[NSMutableArray alloc]init];
    
    //NSMutableDictionary *pawns_and_moves = [[NSMutableDictionary alloc]init];
    for (NSNumber *pawn in tmp) {
        NSMutableArray *tmp2 = [[NSMutableArray alloc]initWithArray:[possibleValidMovesDict objectForKey:[pawn stringValue]]];
        //calculate the response for each move
        for (NSNumber *move in tmp2) {
            /*******************************/
            //play each move to calculate the reward
            //use zombie pawns, don't actually move anything
            ZOMBIE = YES;
            BOOL zombiexbaseempty = XbaseEmpty;
            BOOL zombieobaseempty = ObaseEmpty;
            
            //move the pawn there
            Pawn *mpawn = (Pawn *)[self getChildByTag:[pawn intValue]];
            BOOL ispawninbase = mpawn.isInBase;
            CGPoint origpos = CGPointMake(mpawn.position.x, mpawn.position.y);
            //NSLog(@"orig coords %f-%f",mpawn.position.x,mpawn.position.y);
            Pawn *zombiepawn = mpawn;
            Square *ss = [[Square alloc]init];
            BOOL origssoccuppied;
            int origsshavepawn;
            Square *sss = [[Square alloc]init];
            BOOL origsssoccuppied;
            int origssshavepawn;
            
            //NSLog(@"zombie coords %f-%f",zombiepawn.position.x,zombiepawn.position.y);
            //get square center coordinates from move
           //NSValue *endPoint = [centers objectForKey:[move stringValue]];
           //CGPoint point = [endPoint CGPointValue];
            //CGPoint zombiept;
            //NSLog(@"CENTERS %@",centers);
            //un-occuppy start square if outside of base
            if (!zombiepawn.isInBase) {
                CGPoint pt = CGPointMake(origpos.x,origpos.y);
                NSValue *pp = [NSValue valueWithCGPoint:pt];
                //get the key of the dictionary which corresponds to the tag
                NSArray *temp = [centers allKeysForObject:pp];
                NSString *key = [temp objectAtIndex:0];
                //CCLOG(@"square start tag=%i",[key intValue]);
                ss = (Square *)[self getChildByTag:[key intValue]];
                origssoccuppied = ss.isOccuppied;
                origsshavepawn = ss.havePawn;
                
                Square *zombiesquaress = ss;
                zombiesquaress.isOccuppied = NO;
                zombiesquaress.havePawn = -1;
            }
            
            //we have moved
            zombiepawn.isInBase=NO;
            //move the pawn there
            //[zombiepawn runAction:[CCMoveTo actionWithDuration:0.25 position:point]];
            //zombiept = CGPointMake(point.x,point.y);
           // zombiepawn.position = ccp(point.x, point.y);
            
            //make the square occuppied
            Square *s = (Square *)[self getChildByTag:[move integerValue]];
            BOOL origsoccuppied = s.isOccuppied;
            int origshavepawn = s.havePawn;
            
            
            Square *zombiesquares = s;
            zombiesquares.isOccuppied = YES;
            zombiesquares.havePawn = zombiepawn.tag;
            
            currentPawn = zombiepawn;
            //save remaing pawn values
            int remX = remainingX;
            int remO = remainingO;
            
            if ([self checkElimination:[move intValue]]) {
                //reduce pawn left
                [[zombiepawn type]isEqualToString:@"X"]? --remainingX : --remainingO ;
                //show it
                //[[mpawn type]isEqualToString:@"X"]? [Xlabelvalue setString:[NSString stringWithFormat:@"%i",remainingX]] : [Olabelvalue setString:[NSString stringWithFormat:@"%i",remainingO]];
                //vanish pawn
                //hide with some animation
                //CCLOG(@"current pawn tag=%c",mpawn.tag);
                
                //[self vanishAnimation:mpawn];
                
                //make square free again
                sss = (Square *)[self getChildByTag:[move integerValue]];
                origsssoccuppied=sss.isOccuppied;
                origssshavepawn=sss.havePawn;
               
                Square *zombiesquaresss = sss;
                zombiesquaresss.isOccuppied=NO;
                zombiesquaresss.havePawn=-1;
                
            }
            
            //check if pawn blocked other pawns
            //the pawn that may be blocked by a movement, reside in end_tag-1
            //end_tag+8,end_tag-8
            
            [self eliminateNeighbors:([move integerValue]-1)];
            [self eliminateNeighbors:([move integerValue]+BOARD)];
            [self eliminateNeighbors:([move integerValue]-BOARD)];
            
            //3rd if no base adjacent squares are available
            [self checkBase];
            
            //check game over
            [self checkGameOver:[move integerValue]];
       
            price = [self getReward];  //calculate reward
         
            //NSLog(@"REWARD=%.20f",price);
            

            
            //AI STUFF
            BOOL setTo1 = price==1?YES:NO;
            [self pawnsToInput:[move integerValue]];
            [self singleStep:price setTo1:setTo1];
            
            
            //restore values
            remainingO = remO;
            remainingX = remX;
            mpawn.isInBase=ispawninbase;
            mpawn.position=ccp(origpos.x, origpos.y);
            ss.isOccuppied=origssoccuppied;
            ss.havePawn=origsshavepawn;
            s.isOccuppied=origsoccuppied;
            s.havePawn=origshavepawn;
            sss.isOccuppied=origsssoccuppied;
            sss.havePawn=origssshavepawn;
            XbaseEmpty=zombiexbaseempty;
            ObaseEmpty=zombieobaseempty;
            whoWon=@"";
            
            
            /*******************************/
            
            
            
            //double resp = [self pawnsToInput:[move intValue]];
            //NSLog(@"RESP=%.20f",response);
            //read weights from NSUserDefaults
            NSMutableArray *c_v = [[NSMutableArray alloc]initWithArray:[[NSUserDefaults standardUserDefaults]objectForKey:@"c_v"]];
            NSMutableArray *c_w = [[NSMutableArray alloc]initWithArray:[[NSUserDefaults standardUserDefaults]objectForKey:@"c_w"]];
            [what_to_play addObject:c_v];  //current v_weights
            [what_to_play addObject:c_w];  //current w_weights
            [what_to_play addObject:[NSNumber numberWithInt:[pawn intValue]]];  //pawn
            [what_to_play addObject:[NSNumber numberWithInt:[move intValue]]];  //move
            [what_to_play addObject:[NSNumber numberWithDouble:response]];   //response
            //NSLog(@"reward=%.20f for %i-%i:%.20f",price,[pawn intValue],[move intValue],response);
            //important restore weights
            [net loadWeights:@"v_weights" ww:@"w_weights"];
            //[pawns_and_moves setObject:what_to_play forKey:[NSString stringWithFormat:@"%.30f",resp]];
            //[what_to_play addObject:[NSNumber numberWithDouble:resp]];
        }
    }
    
    //[net UpdateElig:input];   //update eligibility traces
    
    ZOMBIE = NO;
    //if someone won just return;
    if ([baseSquareTags containsObject:[NSNumber numberWithInt:end_tag]]) {
        return;
    }
    
    //NSLog(@"PLAY:%@",what_to_play);
    //every five objects we have the responses
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
    NSMutableArray *tmp2 = [[NSMutableArray alloc]init];
    for (int i=4; i<=[what_to_play count]; i=i+5) {
        [dict setObject:[what_to_play objectAtIndex:i] forKey:[NSString stringWithFormat:@"%i",i]];
    }
    //NSLog(@"DICT:%@",dict);
    //get the values
    for (id key in dict) {
        [tmp2 addObject:[dict objectForKey:key]];
        
    }
    //NSLog(@"TMP2:%@",tmp2);
    NSNumber *quote;  //the pawn to move
    
   
    
    
    //EXPLORE-EXPLOIT
    //get a random double value
    double eSoft = drand48();
    BOOL bestMove=(eSoft<0.9)?true:false; //90%exploitation-10%exploration
    NSString *index;
    if (bestMove){ //exploit
        //sort
        [tmp2 sortUsingSelector:@selector(compare:)];
        //NSLog(@"tmp2=%@",tmp2);
        //last object is the bigger
        NSString *better = [tmp2 lastObject];
        //get back the index
        NSArray *temp = [dict allKeysForObject:better];
        index = [temp objectAtIndex:0];
        //NSLog(@"index=%@",index);
        //now we have the index of the what_to_play array which have the bigger value
        //do index-1 is the move and index-2 is the pawn
        quote=[what_to_play objectAtIndex:[index intValue]-2];
        chosen_move =[what_to_play objectAtIndex:[index intValue]-1];
        CCLOG(@"exploit play:%@-%@:%.20f",quote,chosen_move,[better doubleValue]);
   }else{ //explore
        //clear eligibility traces
        [net clearEligTrace];
        //choose a random move from the array
        NSUInteger randomMove = arc4random() % [tmp2 count];
        NSString *randmove = [tmp2 objectAtIndex:randomMove];
        //get back the index
        NSArray *temp = [dict allKeysForObject:randmove];
        index = [temp objectAtIndex:0];
        NSLog(@"index=%@",index);
        //now we have the index of the what_to_play array which have the bigger value
        //do index-1 is the move and index-2 is the pawn
        quote=[what_to_play objectAtIndex:[index intValue]-2];
        chosen_move =[what_to_play objectAtIndex:[index intValue]-1];
        NSLog(@"explore play:%@-%@",quote,chosen_move);
        
    }
    //the new weights that correspond to the new move
    NSArray* cur_v = [NSArray arrayWithArray:[what_to_play objectAtIndex:[index intValue]-4]];
    NSArray* cur_w = [NSArray arrayWithArray:[what_to_play objectAtIndex:[index intValue]-3]];
    [[NSUserDefaults standardUserDefaults]setObject:cur_v forKey:@"cur_v"];
    [[NSUserDefaults standardUserDefaults]setObject:cur_w forKey:@"cur_w"];
    [net loadWeights:@"cur_v" ww:@"cur_w"];
    [net UpdateElig:input];   //update eligibility traces

    //NSLog(@"pawns and moves:%@",pawns_and_moves)
    
    
    //move the pawn there
    Pawn *mpawn = (Pawn *)[self getChildByTag:[quote intValue]];
    //get square center coordinates from move
    NSValue *endPoint = [centers objectForKey:[chosen_move stringValue]];
    CGPoint point = [endPoint CGPointValue];
    
    //un-occuppy start square if outside of base
    if (!mpawn.isInBase) {
        CGPoint pt = CGPointMake(mpawn.position.x,mpawn.position.y);
        NSValue *pp = [NSValue valueWithCGPoint:pt];
        //get the key of the dictionary which corresponds to the tag
        NSArray *temp = [centers allKeysForObject:pp];
        NSString *key = [temp objectAtIndex:0];
        CCLOG(@"square start tag=%i",[key intValue]);
        Square *sst = (Square *)[self getChildByTag:[key intValue]];
        sst.isOccuppied = NO;
        sst.havePawn = -1;
    }
    //we have moved
    mpawn.isInBase=NO;
    //move the pawn there
    [mpawn runAction:[CCMoveTo actionWithDuration:0.25 position:point]];
    //make the square occupied
    Square *s = (Square *)[self getChildByTag:[chosen_move integerValue]];
    s.isOccuppied = YES;
    s.havePawn = mpawn.tag;
    
    currentPawn=mpawn;
    
    if ([self checkElimination:[chosen_move intValue]]) {
        //reduce pawn left
        [[mpawn type]isEqualToString:@"X"]? --remainingX : --remainingO ;
        //show it
        [[mpawn type]isEqualToString:@"X"]? [Xlabelvalue setString:[NSString stringWithFormat:@"%i",remainingX]] : [Olabelvalue setString:[NSString stringWithFormat:@"%i",remainingO]];
        //vanish pawn
        //hide with some animation
        //CCLOG(@"current pawn tag=%c",mpawn.tag);
        
        [self vanishAnimation:mpawn];
        [self setTouchEnabled:YES];
        //make square free again
        Square *sss = (Square *)[self getChildByTag:[chosen_move integerValue]];
        sss.isOccuppied=NO;
        sss.havePawn=-1;
        
    }
    
    //check if pawn blocked other pawns
    //the pawn that may be blocked by a movement, reside in end_tag-1
    //end_tag+8,end_tag-8
    
    [self eliminateNeighbors:([chosen_move integerValue]-1)];
    [self eliminateNeighbors:([chosen_move integerValue]+BOARD)];
    [self eliminateNeighbors:([chosen_move integerValue]-BOARD)];
    
    //3rd if no base adjacent squares are available
    [self checkBase];
    
    //check game over
    [self checkGameOver:[chosen_move integerValue]];
    
    //price = [self getReward];  //calculate reward
    
    [net storeWeights:@"v_weights" ww:@"w_weights"];
    
    XcanPlay=YES;
}


-(void)singleStep:(double)price setTo1:(BOOL)setTo1{
    int k;
    //[net loadWeights];
    //[net testWeights];
    //[net printWeights];
    //[net Response:input];
    //price = [self getReward];  //calculate reward
    //NSLog(@"REWARD IS:%f",price);
    [net Response:input];
    //[net UpdateElig:input];
    [net setReward:price];
    //NSLog(@"REWARD IS:%f",[net getReward]);
    //NSLog(@"netReward=%f,netGamma=%f,netOut=%f,netOldOut=%f",[net getReward],[net getGamma],[net getOutputNode],[net getOldOutputNode]);
    //[net Response:input];
    if(setTo1)
        [net setOutputNode:1];
    for(k=0;k<[net getOutputNodes];k++)
    {
        double tmp = [net getReward] + [net getGamma] * [net Response:input] - [net getOldOutputNode];
        [net setError:tmp];
    }
    //NSLog(@"ERROR=%.20f",[net getError]);
    //[net UpdateElig:input];
    [net TDlearn];          //backward pass - learning
    //[net printWeights];
    response = [net Response:input];     //forward pass must be done twice to form TD errors
    if(setTo1)
        [net setOutputNode:1];
    for(k=0;k<[net getOutputNodes];k++)
    {
        [net setOldOutputNode:[net getOutputNode]];  //for use in next cycle's TD errors
    }
    //[net UpdateElig:input];   //update eligibility traces
    //[net printEligTrace];
    //[net storeWeights];  //if here, game responds too slow, we are inside multiple loops!
    
}


-(double)getReward{
    
    // an i katastasi einai teliki
    if([whoWon isEqualToString:@"X"] || remainingO==0){
        return LOSS;
    }else if ([whoWon isEqualToString:@"O"]|| remainingX==0){
        return WIN;
    }
    //balanced
    //return ((WIN+LOSS)/2.0);
    
    //win only
    return LOSS;
    /*
    // an xasei kapoio pioni
    double portion=1.0/PAWNS_NUMBER;
    //gia tis ypoloipew periptoseiw epistrefoume to reward os eksis:
    //briskoyme ti diafora tvn pionion ton dyo antipalon (mporei na exasan kapoia piona)
    //kai tin antistoixoume sto diastima (0,1), estw X - o enas pairnei X kai o allos 1-X
    int differenceOfPlayersPawns=remainingX-remainingO;
    double res;
    if(XcanPlay)
    {
        res=differenceOfPlayersPawns*portion;
        // res is now in (-1,1)
        res = 0.5 + res / 2;
        return res;
    }
    else
        if(OcanPlay)
        {
            res=-differenceOfPlayersPawns*portion;
            // res is now in (-1,1)
            res = 0.5 + res / 2;
            return res;
        }
        else
            return 0.5;
     */
}

/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
/* Transforms the pawns configuration to a binary array, that we use for input to the net.
 For each square we have 2 values, one for each player, the appropriate value is set to 1 or both to 0.
 We also measure how many pawns are still inside the base and we use 4 values for each player to
 state the percentage of the pawns that are still inside the base.
 Finally there are two more values, 1 for each, triggered in case someone has already won
 */
/******** -!-!-!-!-!-!-!-!-!-!-!-!-!-!-!- *******/
-(void)pawnsToInput:(int)move{
    
    //double input[2*HIDDEN_SIZE+1];
    NSMutableArray *base_squares = [Board calcBaseSquares];
    
    //occupy move square so we can test it
    Square *test = (Square *)[self getChildByTag:move];
    test.isOccuppied=YES;
    
    //NSLog(@"INPUT NODES=%i",[net getInputNodes]);
    //get all objects
    CCArray *allSprites = [self children];
    int j=0;
    for (CCSprite *s in allSprites){
        //get only the squares
        if ([s isKindOfClass:[Square class]]) {
            
            //count out the base squares
            if ([base_squares containsObject:[NSNumber numberWithInt:s.tag]]) {
                continue;
            }
            Square *cs = (Square *)[self getChildByTag:s.tag];
            //check if square is occuppied
            if(cs.isOccuppied) {
                //NSLog(@"test input[%i]",s.tag);
                if (cs.havePawn>=100 && cs.havePawn<200) {
                    input[j]=1;
                    j++;
                    input[j]=0;
                    j++;
                }else{
                    input[j]=0;
                    j++;
                    input[j]=1;
                    j++;
                }
                
            }else{
                input[j]=0;
                j++;
                input[j]=0;
                j++;
            }
            
        }
        
    }
    
    //safe
    test.isOccuppied=NO;
    
    input[[net getInputNodes]]=1;
    
    int shortcut=2*BOARD*BOARD-4*BASE*BASE;//112
    
    //check how many pawns are in the bases
    int x=0;
    int o=0;
    for (CCSprite *p in allSprites){
        if (p.tag >=100 && p.tag <200) { //X
            Pawn *pawn = (Pawn *)[self getChildByTag:[p tag]];
            if (pawn.isInBase) {
                x++;
            }
        }
        if (p.tag>=200) { //O
            Pawn *pawn = (Pawn *)[self getChildByTag:[p tag]];
            if (pawn.isInBase) {
                o++;
            }
        }
    }
    //NSLog(@"x:%i",x);
    if (x <= PAWNS_NUMBER/4) {
        input[shortcut] = 1;
    }else if (x <= PAWNS_NUMBER/2){
        input[shortcut+1] = 1;
    }else if (x <= 3*PAWNS_NUMBER/4){
        input[shortcut+2] = 1;
    }else{
        input[shortcut+3] = 1;
    }
    
    if (o <= PAWNS_NUMBER/4) {
        input[shortcut+4] = 1;
    }else if (o <= PAWNS_NUMBER/2){
        input[shortcut+5] = 1;
    }else if (o <= 3*PAWNS_NUMBER/4){
        input[shortcut+6] = 1;
    }else{
        input[shortcut+7] = 1;
    }
    
    //who won
    if ([whoWon isEqualToString:@"X"]) {
        input[shortcut+8]=1;
    }else{
        input[shortcut+8]=0;
    }
    if ([whoWon isEqualToString:@"O"]) {
        input[shortcut+9]=1;
    }else{
        input[shortcut+9]=0;
    }
    /*TEST IT
     for (int j=0; j<=[net getInputNodes]; j++) {
     NSLog(@"move%i INPUT[%i]:%f",move,j,input[j]);
     }
     */
    //calculate response
    //response =[net Response:input];
    //NSLog(@"TEST RESP %.20f",resp);
    //[bestResponse addObject:[NSNumber numberWithDouble:[net Response:input]]];
    //net.inputNode[net.inputNodes] = net.BIAS;
    //int shortcut=2*BOARD*BOARD-4*BASE*BASE;//112
}

-(void)ccTouchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
    
    
    UITouch *touch = [touches anyObject];
    
    
    CGPoint location = [touch locationInView:[touch view]];
    location = [[CCDirector sharedDirector]convertToGL:location];
    
    
    
    CGPoint oldLocation = [touch previousLocationInView:[touch view]];
    oldLocation = [[CCDirector sharedDirector] convertToGL:oldLocation];
    oldLocation = [self convertToNodeSpace:oldLocation];
    
    CGPoint translation = ccpSub(location, oldLocation);
    
    
    //handle only the pawn you touch
    if (CGRectContainsPoint([currentPawn boundingBox], location)) {
        //we move only if it is our turn
        if ([[currentPawn type]isEqualToString:@"X"] && XcanPlay) {
            
            [self dragPawn:translation];
            
        }else if ([[currentPawn type]isEqualToString:@"O"] && OcanPlay) {
            [self dragPawn:translation];
        }
    }
    //[self dragPawn:translation];
    
}

- (void)selectPawn:(CGPoint)location {
    
    //get all sprites
    CCArray *allSprites = [self children];
    Pawn *pawn = nil;
    for (CCSprite *p in allSprites){
        
        //handle only the pawn you touch
        if (CGRectContainsPoint([p boundingBox], location)) {
            //only touch pawns, not squares
            if ([p isKindOfClass:[Pawn class]]){
                //CCLOG(@"TAG=%i",[p tag]);
                
                pawn = (Pawn *)[self getChildByTag:[p tag]];
                
                //check who's turn to play
                if ([[pawn type]isEqualToString:@"X"] && !XcanPlay) {
                    
                    return;
                }else if ([[pawn type]isEqualToString:@"O"] && !OcanPlay) {
                    return;
                }
                if ([[pawn type]isEqualToString:@"X"]) {
                    OcanPlay = YES;
                    
                }else if([[pawn type]isEqualToString:@"O"]) {
                    XcanPlay = YES;
                    
                }
                
                //CCLOG(@"pawn tag=%i",[p tag]);
                //save start position so we can come back
                //if end position is somwehere in the middle
                touchstartx = p.position.x;
                touchstarty = p.position.y;
                
                //also get the coordinates of the current square
                //these are the start coordinates that are going to be used
                //for checking valid movement
                if (!pawn.isInBase) {
                    //the pawn lies in the middle of the square
                    //they have the same anchor point
                    //we can get the square tag and from there the coordinates
                    CGPoint pt = CGPointMake(p.position.x,p.position.y);
                    NSValue *pp = [NSValue valueWithCGPoint:pt];
                    //get the key of the dictionary which corresponds to the tag
                    NSArray *temp = [centers allKeysForObject:pp];
                    NSString *key = [temp objectAtIndex:0];
                    //CCLOG(@"square start tag=%i",[key intValue]);
                    Square *s = (Square *)[self getChildByTag:[key intValue]];
                    startposx = s.xcoord;
                    startposy = s.ycoord;
                    //save also the start tag
                    starttag = s.tag;
                }
                
                break;  //break the loop
            }
        }
        
    }
    
    currentPawn=pawn;
    
    //wiggle effect to see the selected pawn
    //create sequence of actions
    //reset position first
    [pawn runAction:[CCRotateTo actionWithDuration:0.1 angle:0]];
    //do some rotations
    CCRotateTo *rotLeft = [CCRotateBy actionWithDuration:0.1 angle:-4.0];
    CCRotateTo *rotCenter = [CCRotateBy actionWithDuration:0.1 angle:0.0];
    CCRotateTo *rotRight = [CCRotateBy actionWithDuration:0.1 angle:4.0];
    CCSequence *rotSeq = [CCSequence actions:rotLeft, rotCenter, rotRight, rotCenter, nil];
    [pawn runAction:[CCRepeatForever actionWithAction:rotSeq]];
    
    
}



-(void)ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    
    UITouch *touch = [touches anyObject];
    CGPoint location = [touch locationInView:[touch view]];
    location = [[CCDirector sharedDirector]convertToGL:location];
    
    //server can only touch X, client can only touch O
    if (P2P) {
        
        //get all sprites
        CCArray *allSprites = [self children];
        for (CCSprite *p in allSprites){
            //handle only the pawn you touch
            if (CGRectContainsPoint([p boundingBox], location)) {
                //only touch pawns, not squares
                if (_isServer && [p isKindOfClass:[Pawn class]]){
                    if (p.tag >= 200) {
                        server_client_moved=NO;
                        return;
                    }
                }else if (!_isServer && [p isKindOfClass:[Pawn class]]){
                    if (p.tag < 200) {
                        server_client_moved=NO;
                        return;
                    }
                }
            }
        }
    }
    
    [self selectPawn:location];
    
}

@end
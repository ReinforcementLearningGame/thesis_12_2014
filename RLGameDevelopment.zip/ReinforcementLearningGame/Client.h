//
//  Client.h
//  RL_Game
//
//  Created by Zois Avgerinos on 9/17/13.
//  Copyright (c) 2013 Zois Avgerinos. All rights reserved.
//

#import <Foundation/Foundation.h>
@class Client;
@protocol ClientDelegate <NSObject>

- (void)matchmakingClient:(Client *)client serverBecameAvailable:(NSString *)peerID;
- (void)matchmakingClient:(Client *)client serverBecameUnavailable:(NSString *)peerID;
- (void)matchmakingClient:(Client *)client didDisconnectFromServer:(NSString *)peerID;
- (void)matchmakingClientNoNetwork:(Client *)client;
- (void)matchmakingClient:(Client *)client didConnectToServer:(NSString *)peerID;
@end

@interface Client : NSObject<GKSessionDelegate>
@property (nonatomic, strong, readonly) NSArray *availableServers;
@property (nonatomic, strong, readonly) GKSession *session;
@property (nonatomic, strong) id <ClientDelegate> delegate;
- (void)startSearchingForServersWithSessionID:(NSString *)sessionID;
- (NSUInteger)availableServerCount;
- (NSString *)peerIDForAvailableServerAtIndex:(NSUInteger)index;
- (NSString *)displayNameForPeerID:(NSString *)peerID;
- (void)disconnectFromServer;
- (void)connectToServerWithPeerID:(NSString *)peerID;
@end

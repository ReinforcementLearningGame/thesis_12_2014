//
//  Square.m
//  RL_Game
//
//  Created by Zois Avgerinos on 8/29/13.
//  Copyright 2013 Zois Avgerinos. All rights reserved.
//

#import "Square.h"


@implementation Square

@synthesize squareSprite;
@synthesize isOccuppied;
@synthesize havePawn;
@synthesize xcoord;
@synthesize ycoord;
@end

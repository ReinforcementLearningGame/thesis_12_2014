//
//  NeuralNet.h
//  ReinforcementLearningGame
//
//  Created by Zois Avgerinos on 11/13/13.
//  Copyright (c) 2013 Zois Avgerinos. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Constants.h"


@interface NeuralNet : NSObject{
    int inputNodes,hiddenNodes,outputNodes;
    double ALPHA,BETA,GAMMA, LAMBDA; //constants for learning procedure
    double BIAS;//=0.5;//bias that each neuron has (input node 0),strength of the bias (constant input) contribution
    
    double inputNode[2*HIDDEN_SIZE+1]; //array of input nodes//123 elements
    double hiddenNode[HIDDEN_SIZE+1]; //array of hidden nodes //62 elements
    double outputNode[1]; //array of output nodes //1 element
    double oldOutputNode[1]; //array used for updating weights
    
    double error[1]; //TD error pou afora to output node
    double reward[1]; //the reward received for each decision
    
    //weights from input to hidden layer
    double v[2*HIDDEN_SIZE+1][HIDDEN_SIZE+1];
    //weights from hidden to output layer
    double w[HIDDEN_SIZE+1][1];
    //hidden trace
    double ev[2*HIDDEN_SIZE+1][HIDDEN_SIZE+1][1];
    //output trace
    double ew[HIDDEN_SIZE+1][1];
    
    int owner;// which player plays??

}


//old bad habbits, setters and getters
-(int)getInputNodes;
-(int)getOutputNodes;
-(void)setOutputNode:(double)val;
-(double)getOldOutputNode;
-(void)setOldOutputNode:(double)val;
-(void)setReward:(double)val;
-(double)getReward;
-(double)getOutputNode;
-(double)getError;
-(void)setError:(double)val;
-(double)getGamma;
-(void)printWeights;
-(void)testWeights;
-(void)loadWeights:(NSString*)vw ww:(NSString*)ww;
-(void)storeWeights:(NSString*)vw ww:(NSString*)ww;
-(double)Response:(double[])input;
-(void)TDlearn;
-(void)UpdateElig:(double[])input;
-(void) printEligTrace;
-(void) clearEligTrace;
-(void)initWithParams:(int)which :(int)input :(int)hidden :(int)output :(double)gamma :(double)lambda;

@end

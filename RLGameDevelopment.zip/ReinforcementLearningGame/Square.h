//
//  Square.h
//  RL_Game
//
//  Created by Zois Avgerinos on 8/29/13.
//  Copyright 2013 Zois Avgerinos. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface Square : CCSprite {
    //instance variables
    NSString *squareSprite;
    BOOL isOccuppied;
    int havePawn;   //tag of pawn that's on the square
    //coordinates
    NSInteger xcoord;
    NSInteger ycoord;
    
}

//accessors
@property (nonatomic,readwrite,retain) NSString *squareSprite;
@property (nonatomic,readwrite) BOOL isOccuppied;
@property (nonatomic,readwrite) int havePawn;
@property (nonatomic,readwrite) NSInteger xcoord;
@property (nonatomic,readwrite) NSInteger ycoord;

@end

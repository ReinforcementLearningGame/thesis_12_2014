//
//  HostGame.m
//  RL_Game
//
//  Created by Zois Avgerinos on 9/16/13.
//  Copyright 2013 Zois Avgerinos. All rights reserved.
//

#import "HostGame.h"
#import "HelloWorldLayer.h"
#import "Server.h"
#import "RLGameRun.h"

@implementation HostGame{
    Server *_server;
    QuitReason _quitReason;
}

@synthesize hostLabel=_hostLabel;
@synthesize nameLabel=_nameLabel;
@synthesize connectingLabel=_connectingLabel;
@synthesize connectedLabel =_connectedLabel;
@synthesize name_Label=_name_Label;
@synthesize delegate=_delegate;

+(CCScene *) scene {
    CCScene *scene = [CCScene node];
    HostGame *layer = [HostGame node];
    [scene addChild: layer];
    return scene;
}

-(id)init{
    if( (self=[super init]) ) {
        //ask director for the window size
		CGSize winSize = [CCDirector sharedDirector].winSize;
        
        //MENU BUTTONS
        CCMenuItem *backToMenu = [CCMenuItemFont itemWithString:@"back" target:self selector:@selector(onStartBackPressed)];
        CCMenuItem *startHost = [CCMenuItemFont itemWithString:@"start" target:self selector:@selector(onStartHostPressed)];

        //Create the real Menu
        CCMenu *menu = [CCMenu menuWithItems:backToMenu,startHost, nil];
        //position
        //menu.position = ccp(winSize.width * 0.5f, winSize.height * 0.4f);
        [menu setPosition:ccp( winSize.width/2 - 50, winSize.height/2 - 130)];
        //alignment
        //[menu alignItemsVerticallyWithPadding:15];
        [menu alignItemsHorizontallyWithPadding:20];
        //Add the menu as a child to this layer
        [self addChild:menu];
        
        //TOP LABEL
        _hostLabel = [CCLabelTTF labelWithString:@"HOST Game" fontName:@"Marker Felt" fontSize:64];
        _hostLabel.position =  ccp( winSize.width /2 , winSize.height/2+100 );
        // add the label as a child to this Layer
        [self addChild: _hostLabel];
        
        //NAME LABEL
        _name_Label = [CCLabelTTF labelWithString:@"Name:" fontName:@"Marker Felt" fontSize:32];
        _name_Label.position =  ccp(50 , winSize.height/2+20 );
        // add the label as a child to this Layer
        [self addChild: _name_Label];
        _nameLabel = [CCLabelTTF labelWithString:@"" fontName:@"Marker Felt" fontSize:16];
        _nameLabel.anchorPoint=ccp(0,1);
        _nameLabel.position =  ccp(100 , winSize.height/2+30 );
        // add the label as a child to this Layer
        [self addChild: _nameLabel];

        
        //CONNECTING LABEL
        _connectingLabel = [CCLabelTTF labelWithString:@"Opponent:" fontName:@"Marker Felt" fontSize:32];
        _connectingLabel.position =  ccp(70, winSize.height/2 -20);
        // add the label as a child to this Layer
        [self addChild: _connectingLabel];
        
        //CONNECTED LABEL
        _connectedLabel = [CCLabelTTF labelWithString:@"" fontName:@"Marker Felt" fontSize:24];
        _connectedLabel.anchorPoint=ccp(0,1);  //so the first letter to begin in x=250
        _connectedLabel.position =  ccp(140, winSize.height/2 -10);
        // add the label as a child to this Layer
        [self addChild: _connectedLabel];
               
                
        //enable touches
        self.touchEnabled = YES;
        
        //SERVER
        if (_server == nil)
        {
            _server = [[[Server alloc] init]retain];
            _server.maxClients = 1;
            [_server startAcceptingConnectionsForSessionID:SESSION_ID];
            
            [_nameLabel setString:[NSString stringWithFormat:@"%@",_server.session.displayName]];
            
        }
        
        _server.delegate = self;
    }
    return self;
}

/*
-(void)addUIViews{
    //NAME TEXTFIELD
    _nameTextField = [[UITextField alloc] initWithFrame:CGRectMake(200, 200, 150, 50)];
    _nameTextField.delegate = self;
    _nameTextField.placeholder=@"NAME TEXT";
    //position
    CGRect frame = _nameTextField.frame;
    frame.origin.y=40;
    frame.origin.x=40;
    _nameTextField.frame=frame;
    [[CCDirector sharedDirector].view addSubview:_nameTextField];
    
    //TABLE VIEW OF CONNECTED CLIENTS
    _connectedTable = [[UITableView alloc]initWithFrame:CGRectMake(10, 160, 400, 100) style:UITableViewStylePlain];
    _connectedTable.delegate=self;
    _connectedTable.dataSource=self;
    [[CCDirector sharedDirector].view addSubview:_connectedTable];

   }*/

-(void)onStartHostPressed{
    if (_server != nil && [_server connectedClientCount] > 0)
	{
        NSString *name = [[_connectedLabel string] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        if ([name length] == 0)
            name = _server.session.displayName;
		
		if ([name length] == 0)
			name = _server.session.displayName;
        
		[_server stopAcceptingConnections];
        
        [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:0.5f scene:[RLGameRun sceneServerWithParams:_server.session playerName:name client:_server.connectedClients]]];
        
		//[self.delegate hostViewController:self startGameWithSession:_matchmakingServer.session playerName:name clients:_matchmakingServer.connectedClients];
	}
    
}

-(void)onStartBackPressed{
    
    _quitReason = QuitReasonUserQuit;
	[_server endSession];
 
    
    CCScene *MainMenuScene = [HelloWorldLayer scene];
    //[self.delegate hostViewControllerDidCancel:self];
    [[CCDirector sharedDirector] replaceScene:[CCTransitionJumpZoom transitionWithDuration:0.5f scene:MainMenuScene]];

}


#pragma mark - MatchmakingServerDelegate

- (void)matchmakingServer:(Server *)server clientDidConnect:(NSString *)peerID
{
	[_connectedLabel setString:[_server displayNameForPeerID:peerID]];
}

- (void)matchmakingServer:(Server *)server clientDidDisconnect:(NSString *)peerID
{
	[_connectedLabel setString:@""];
}

- (void)matchmakingServerSessionDidEnd:(Server *)server
{
	_server.delegate = nil;
	_server = nil;
	[_connectedLabel setString:@""];
    [self showDisconnectedAlert];
    
    CCScene *MainMenuScene = [HelloWorldLayer scene];
    [[CCDirector sharedDirector] replaceScene:[CCTransitionJumpZoom transitionWithDuration:0.5f scene:MainMenuScene]];
	//[self.delegate hostViewController:self didEndSessionWithReason:_quitReason];
}

- (void)matchmakingServerNoNetwork:(Server *)server
{
	_quitReason = QuitReasonNoNetwork;
}

- (void)showNoNetworkAlert
{
	UIAlertView *alertView = [[UIAlertView alloc]
                              initWithTitle:NSLocalizedString(@"No Network", @"No network alert title")
                              message:NSLocalizedString(@"To use multiplayer, please enable Bluetooth or Wi-Fi in your device's Settings.", @"No network alert message")
                              delegate:nil
                              cancelButtonTitle:NSLocalizedString(@"OK", @"Button: OK")
                              otherButtonTitles:nil];
    
	[alertView show];
}


- (void)showDisconnectedAlert
{
	UIAlertView *alertView = [[UIAlertView alloc]
                              initWithTitle:NSLocalizedString(@"Disconnected", @"Server disconnected alert title")
                              message:NSLocalizedString(@"You were disconnected from the game.", @"Server disconnected alert message")
                              delegate:nil
                              cancelButtonTitle:NSLocalizedString(@"OK", @"Button: OK")
                              otherButtonTitles:nil];
    
	[alertView show];
}

@end

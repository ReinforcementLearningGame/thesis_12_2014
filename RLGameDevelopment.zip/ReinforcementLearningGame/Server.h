//
//  Server.h
//  RL_Game
//
//  Created by Zois Avgerinos on 9/17/13.
//  Copyright (c) 2013 Zois Avgerinos. All rights reserved.
//

#import <Foundation/Foundation.h>
@class Server;

@protocol ServerDelegate <NSObject>

- (void)matchmakingServer:(Server *)server clientDidConnect:(NSString *)peerID;
- (void)matchmakingServer:(Server *)server clientDidDisconnect:(NSString *)peerID;
- (void)matchmakingServerSessionDidEnd:(Server *)server;
- (void)matchmakingServerNoNetwork:(Server *)server;

@end

@interface Server : NSObject<GKSessionDelegate>

@property (nonatomic, assign) int maxClients;
@property (nonatomic, strong, readonly) NSArray *connectedClients;
@property (nonatomic, strong, readonly) GKSession *session;

@property (nonatomic, strong) id <ServerDelegate> delegate;

- (void)startAcceptingConnectionsForSessionID:(NSString *)sessionID;

- (NSUInteger)connectedClientCount;
- (NSString *)peerIDForConnectedClientAtIndex:(NSUInteger)index;
- (NSString *)displayNameForPeerID:(NSString *)peerID;
- (void)endSession;
- (void)stopAcceptingConnections;
@end

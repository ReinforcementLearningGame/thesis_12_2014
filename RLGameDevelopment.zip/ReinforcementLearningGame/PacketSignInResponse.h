//
//  PacketSignInResponse.h
//  ReinforcementLearningGame
//
//  Created by Zois Avgerinos on 9/25/13.
//  Copyright (c) 2013 Zois Avgerinos. All rights reserved.
//

#import "Packet.h"

@interface PacketSignInResponse : Packet

@property (nonatomic, copy) NSString *playerName;

+ (id)packetWithPlayerName:(NSString *)playerName;

@end
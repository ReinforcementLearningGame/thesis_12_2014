//
//  Pawn.h
//  RL_Game
//
//  Created by Zois Avgerinos on 8/30/13.
//  Copyright 2013 Zois Avgerinos. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface Pawn : CCSprite {
    //instance variables
    NSString *pawnSprite;
    NSString *type;
    BOOL isInBase;
    
}

@property (nonatomic,readwrite,retain) NSString *pawnSprite;
@property (nonatomic,readwrite,retain) NSString *type;
@property (nonatomic,readwrite) BOOL isInBase;

@end
